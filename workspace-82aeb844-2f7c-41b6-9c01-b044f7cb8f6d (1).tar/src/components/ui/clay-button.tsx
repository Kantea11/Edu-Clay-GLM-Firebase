"use client"

import { forwardRef } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { VariantProps } from "class-variance-authority"

const ClayButton = forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> &
  VariantProps<typeof import("@/components/ui/button").buttonVariants> & {
    variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
    size?: "default" | "sm" | "lg" | "icon"
  }
>(({ className, variant = "default", size = "default", children, ...props }, ref) => {
  return (
    <Button
      ref={ref}
      variant={variant}
      size={size}
      className={cn(
        "clay-button",
        "hover:transform hover:-translate-y-0.5 active:translate-y-0",
        "bg-[var(--clay-bg)] shadow-[var(--clay-shadow-light)]",
        "hover:shadow-[var(--clay-shadow-hover)] active:shadow-[var(--clay-shadow-dark)]",
        "border-0",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  )
})

ClayButton.displayName = "ClayButton"

export { ClayButton }