"use client"

import { forwardRef } from "react"
import { cn } from "@/lib/utils"

const ClayCard = forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    inset?: boolean
    hover?: boolean
  }
>(({ className, inset = false, hover = true, children, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        "clay-card",
        inset && "clay-card-inset",
        hover && "hover:shadow-[var(--clay-shadow-hover)]",
        "p-6 transition-all duration-300",
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
})

ClayCard.displayName = "ClayCard"

export { ClayCard }