"use client"

import { forwardRef } from "react"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"

const ClayInput = forwardRef<
  HTMLInputElement,
  React.ComponentProps<"input">
>(({ className, type, ...props }, ref) => {
  return (
    <Input
      ref={ref}
      type={type}
      className={cn(
        "clay-input",
        "bg-[var(--clay-bg)] shadow-[var(--clay-shadow-dark)]",
        "focus:shadow-[var(--clay-shadow-light)] focus:outline-none",
        "border-0",
        className
      )}
      {...props}
    />
  )
})

ClayInput.displayName = "ClayInput"

export { ClayInput }