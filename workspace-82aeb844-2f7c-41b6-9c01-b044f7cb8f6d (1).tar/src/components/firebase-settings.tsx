"use client"

import { useState } from "react"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  Settings, 
  Save, 
  TestTube, 
  Eye,
  EyeOff,
  Copy,
  Check,
  AlertTriangle,
  Info
} from "lucide-react"
import { firebaseAuth } from "@/lib/firebase-auth"

interface FirebaseConfig {
  apiKey: string
  authDomain: string
  projectId: string
  storageBucket: string
  messagingSenderId: string
  appId: string
}

export function FirebaseSettings() {
  const [config, setConfig] = useState<FirebaseConfig>({
    apiKey: "AIzaSyB661Q0U9-fmgi3jBEktiD4f6yLI1kDTIg",
    authDomain: "report-card-8c7de.firebaseapp.com",
    projectId: "report-card-8c7de",
    storageBucket: "report-card-8c7de.firebasestorage.app",
    messagingSenderId: "135773954243",
    appId: "1:135773954243:web:0dbc02f27210477c100276"
  })

  const [showSecrets, setShowSecrets] = useState<{ [key: string]: boolean }>({})
  const [testResults, setTestResults] = useState<{ [key: string]: { success: boolean; message: string } }>({})
  const [isTesting, setIsTesting] = useState(false)

  const toggleSecret = (field: string) => {
    setShowSecrets(prev => ({
      ...prev,
      [field]: !prev[field]
    }))
  }

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text)
    setTestResults(prev => ({
      ...prev,
      [field]: { success: true, message: "Copied to clipboard!" }
    }))
    setTimeout(() => {
      setTestResults(prev => {
        const newResults = { ...prev }
        delete newResults[field]
        return newResults
      })
    }, 2000)
  }

  const testConnection = async () => {
    setIsTesting(true)
    setTestResults({})

    try {
      // Test Firebase initialization
      const { initializeApp } = await import("firebase/app")
      const { getAuth } = await import("firebase/auth")
      const { getFirestore } = await import("firebase/firestore")
      const { getStorage } = await import("firebase/storage")

      const testApp = initializeApp(config, "test-app")
      const auth = getAuth(testApp)
      const firestore = getFirestore(testApp)
      const storage = getStorage(testApp)

      // Test Firestore
      try {
        const { doc, setDoc, serverTimestamp } = await import("firebase/firestore")
        const testRef = doc(firestore, "_test", "connection")
        await setDoc(testRef, {
          test: true,
          timestamp: serverTimestamp()
        })
        setTestResults(prev => ({
          ...prev,
          firestore: { success: true, message: "Firestore connection successful" }
        }))
      } catch (error) {
        setTestResults(prev => ({
          ...prev,
          firestore: { success: false, message: `Firestore connection failed: ${error instanceof Error ? error.message : "Unknown error"}` }
        }))
      }

      // Test Storage
      try {
        const { ref, uploadBytes, getDownloadURL } = await import("firebase/storage")
        const testStorageRef = ref(storage, "_test/connection.txt")
        const testBlob = new Blob(["test"], { type: "text/plain" })
        await uploadBytes(testStorageRef, testBlob)
        await getDownloadURL(testStorageRef)
        setTestResults(prev => ({
          ...prev,
          storage: { success: true, message: "Storage connection successful" }
        }))
      } catch (error) {
        setTestResults(prev => ({
          ...prev,
          storage: { success: false, message: `Storage connection failed: ${error instanceof Error ? error.message : "Unknown error"}` }
        }))
      }

      // Clean up test app (if delete method exists)
      try {
        if (typeof (testApp as any).delete === 'function') {
          await (testApp as any).delete()
        }
      } catch (error) {
        console.log('Could not delete test app:', error)
      }

      setTestResults(prev => ({
        ...prev,
        overall: { success: true, message: "Firebase configuration test completed" }
      }))
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        overall: { success: false, message: `Firebase initialization failed: ${error instanceof Error ? error.message : "Unknown error"}` }
      }))
    } finally {
      setIsTesting(false)
    }
  }

  const saveConfig = () => {
    // In a real application, this would update environment variables
    // For now, we'll just show a success message
    setTestResults(prev => ({
      ...prev,
      save: { success: true, message: "Configuration saved! Please restart the application." }
    }))
  }

  const configFields = [
    {
      key: "apiKey" as keyof FirebaseConfig,
      label: "API Key",
      placeholder: "your-firebase-api-key",
      secret: true
    },
    {
      key: "authDomain" as keyof FirebaseConfig,
      label: "Auth Domain",
      placeholder: "your-project.firebaseapp.com",
      secret: false
    },
    {
      key: "projectId" as keyof FirebaseConfig,
      label: "Project ID",
      placeholder: "your-project-id",
      secret: false
    },
    {
      key: "storageBucket" as keyof FirebaseConfig,
      label: "Storage Bucket",
      placeholder: "your-project.appspot.com",
      secret: false
    },
    {
      key: "messagingSenderId" as keyof FirebaseConfig,
      label: "Messaging Sender ID",
      placeholder: "123456789",
      secret: false
    },
    {
      key: "appId" as keyof FirebaseConfig,
      label: "App ID",
      placeholder: "1:123456789:web:abcdef123456",
      secret: true
    }
  ]

  return (
    <div className="space-y-6">
      {/* Configuration Form */}
      <ClayCard className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <h2 className="text-xl font-semibold">Firebase Configuration</h2>
          </div>
          <div className="flex space-x-2">
            <ClayButton onClick={testConnection} disabled={isTesting}>
              <TestTube className="h-4 w-4 mr-2" />
              {isTesting ? "Testing..." : "Test Connection"}
            </ClayButton>
            <ClayButton onClick={saveConfig}>
              <Save className="h-4 w-4 mr-2" />
              Save Configuration
            </ClayButton>
          </div>
        </div>

        <div className="space-y-4">
          {configFields.map((field) => (
            <div key={field.key}>
              <label className="block text-sm font-medium mb-2">
                {field.label}
              </label>
              <div className="flex space-x-2">
                <div className="flex-1 relative">
                  <ClayInput
                    type={showSecrets[field.key] || !field.secret ? "text" : "password"}
                    value={config[field.key]}
                    onChange={(e) => setConfig(prev => ({
                      ...prev,
                      [field.key]: e.target.value
                    }))}
                    placeholder={field.placeholder}
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => toggleSecret(field.key)}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showSecrets[field.key] || !field.secret ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
                <ClayButton
                  size="icon"
                  variant="outline"
                  onClick={() => copyToClipboard(config[field.key], field.key)}
                >
                  <Copy className="h-4 w-4" />
                </ClayButton>
              </div>
              {testResults[field.key] && (
                <div className={`mt-1 p-2 rounded text-xs ${
                  testResults[field.key].success 
                    ? "bg-green-100 text-green-800" 
                    : "bg-red-100 text-red-800"
                }`}>
                  {testResults[field.key].message}
                </div>
              )}
            </div>
          ))}
        </div>
      </ClayCard>

      {/* Test Results */}
      {testResults.overall && (
        <ClayCard className="p-6">
          <h3 className="text-lg font-semibold mb-4">Connection Test Results</h3>
          <div className="space-y-3">
            {Object.entries(testResults).map(([key, result]) => {
              if (key === "overall" || key === "save") return null
              
              return (
                <div key={key} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center space-x-2">
                    {result.success ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                    )}
                    <span className="font-medium capitalize">{key}</span>
                  </div>
                  <span className={`text-sm ${
                    result.success ? "text-green-600" : "text-red-600"
                  }`}>
                    {result.message}
                  </span>
                </div>
              )
            })}
          </div>
        </ClayCard>
      )}

      {/* Setup Instructions */}
      <ClayCard className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Info className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Firebase Setup Instructions</h3>
        </div>
        
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Step 1: Create Firebase Project</h4>
            <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
              <li>Go to <a href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer" className="underline">Firebase Console</a></li>
              <li>Click "Add project" and follow the setup wizard</li>
              <li>Enable Google Analytics if desired</li>
            </ol>
          </div>

          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <h4 className="font-medium text-green-800 mb-2">Step 2: Enable Required Services</h4>
            <ul className="text-sm text-green-700 space-y-1 list-disc list-inside">
              <li>Authentication: Enable Email/Password authentication</li>
              <li>Firestore Database: Create database in test mode</li>
              <li>Cloud Storage: Create storage bucket</li>
            </ul>
          </div>

          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">Step 3: Get Configuration</h4>
            <ol className="text-sm text-yellow-700 space-y-1 list-decimal list-inside">
              <li>In Firebase Console, click "Project settings"</li>
              <li>Scroll down to "Your apps" section</li>
              <li>Click the web app icon (&lt;/&gt;)</li>
              <li>Register app (skip hosting setup)</li>
              <li>Copy the Firebase configuration object</li>
              <li>Paste the values into the form above</li>
            </ol>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="font-medium text-purple-800 mb-2">Step 4: Security Rules (Important!)</h4>
            <div className="text-sm text-purple-700 space-y-2">
              <p><strong>Firestore Rules:</strong></p>
              <pre className="bg-purple-100 p-2 rounded text-xs overflow-x-auto">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}`}
              </pre>
              <p><strong>Storage Rules:</strong></p>
              <pre className="bg-purple-100 p-2 rounded text-xs overflow-x-auto">
{`rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}`}
              </pre>
            </div>
          </div>
        </div>
      </ClayCard>
    </div>
  )
}