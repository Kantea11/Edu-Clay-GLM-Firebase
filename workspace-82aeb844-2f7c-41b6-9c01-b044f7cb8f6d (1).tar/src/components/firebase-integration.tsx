"use client"

import { useState, useEffect } from "react"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { 
  Database, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  AlertCircle,
  CheckCircle,
  Settings,
  User,
  Shield
} from "lucide-react"
import { firebaseSync } from "@/lib/firebase-sync"
import { firebaseAuth } from "@/lib/firebase-auth"
import { firebaseStorage } from "@/lib/firebase-storage"

interface FirebaseStatus {
  connected: boolean
  syncStatus: {
    syncInProgress: boolean
    activeListeners: number
    collections: string[]
  }
  authStatus: {
    isAuthenticated: boolean
    user?: {
      uid: string
      email: string | null
      displayName: string | null
      role: string
    }
  }
  storageStatus: {
    available: boolean
    totalFiles?: number
  }
}

export function FirebaseIntegration() {
  const [status, setStatus] = useState<FirebaseStatus>({
    connected: false,
    syncStatus: firebaseSync.getSyncStatus(),
    authStatus: {
      isAuthenticated: firebaseAuth.isAuthenticated(),
      user: firebaseAuth.getCurrentUser() || undefined
    },
    storageStatus: {
      available: false
    }
  })
  
  const [syncResults, setSyncResults] = useState<{
    [key: string]: { success: boolean; message: string; timestamp: Date }
  }>({})

  // Update status periodically
  useEffect(() => {
    const interval = setInterval(() => {
      updateStatus()
    }, 5000)

    // Set up auth state listener
    const unsubscribeAuth = firebaseAuth.onAuthStateChanged((user) => {
      setStatus(prev => ({
        ...prev,
        authStatus: {
          isAuthenticated: user !== null,
          user: user ? {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            role: user.role
          } : undefined
        }
      }))
    })

    // Initial status check
    checkFirebaseConnection()
    updateStatus()

    return () => {
      clearInterval(interval)
      unsubscribeAuth()
    }
  }, [])

  const updateStatus = () => {
    setStatus(prev => ({
      ...prev,
      syncStatus: firebaseSync.getSyncStatus(),
      authStatus: {
        isAuthenticated: firebaseAuth.isAuthenticated(),
        user: firebaseAuth.getCurrentUser() || undefined
      }
    }))
  }

  const checkFirebaseConnection = async () => {
    try {
      // Try to initialize Firebase to check connection
      const { db } = await import("@/lib/firebase")
      setStatus(prev => ({ ...prev, connected: true }))
    } catch (error) {
      setStatus(prev => ({ ...prev, connected: false }))
    }
  }

  const syncCollection = async (collectionName: string) => {
    try {
      const result = await firebaseSync.syncCollectionToFirebase(collectionName)
      setSyncResults(prev => ({
        ...prev,
        [collectionName]: {
          success: result.success,
          message: result.success 
            ? `Synced ${result.syncedRecords} records successfully`
            : `Sync failed: ${result.errors.join(", ")}`,
          timestamp: new Date()
        }
      }))
      updateStatus()
    } catch (error) {
      setSyncResults(prev => ({
        ...prev,
        [collectionName]: {
          success: false,
          message: `Sync failed: ${error instanceof Error ? error.message : "Unknown error"}`,
          timestamp: new Date()
        }
      }))
    }
  }

  const syncAllCollections = async () => {
    const collections = [
      "academic_terms",
      "subjects", 
      "teachers",
      "classrooms",
      "students",
      "grades",
      "school_information"
    ]

    for (const collection of collections) {
      await syncCollection(collection)
    }
  }

  const toggleRealtimeSync = (collectionName: string) => {
    const isActive = status.syncStatus.collections.includes(collectionName)
    
    if (isActive) {
      firebaseSync.stopRealtimeSync(collectionName)
    } else {
      firebaseSync.setupRealtimeSync(collectionName)
    }
    
    updateStatus()
  }

  const collections = [
    { name: "academic_terms", label: "Academic Terms", icon: "📅" },
    { name: "subjects", label: "Subjects", icon: "📚" },
    { name: "teachers", label: "Teachers", icon: "👨‍🏫" },
    { name: "classrooms", label: "Classrooms", icon: "🏫" },
    { name: "students", label: "Students", icon: "👨‍🎓" },
    { name: "grades", label: "Grades", icon: "📊" },
    { name: "school_information", label: "School Info", icon: "🏢" }
  ]

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <ClayCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>Firebase Integration</span>
          </h2>
          <div className="flex items-center space-x-2">
            {status.connected ? (
              <>
                <Wifi className="h-4 w-4 text-green-500" />
                <span className="text-sm text-green-600">Connected</span>
              </>
            ) : (
              <>
                <WifiOff className="h-4 w-4 text-red-500" />
                <span className="text-sm text-red-600">Disconnected</span>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Authentication Status */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <User className="h-4 w-4" />
              <span className="font-medium">Authentication</span>
            </div>
            {status.authStatus.isAuthenticated ? (
              <div className="space-y-1">
                <p className="text-sm text-green-600">Authenticated</p>
                <p className="text-xs text-muted-foreground">
                  {status.authStatus.user?.displayName || status.authStatus.user?.email}
                </p>
                <p className="text-xs text-muted-foreground">
                  Role: {status.authStatus.user?.role}
                </p>
              </div>
            ) : (
              <p className="text-sm text-red-600">Not authenticated</p>
            )}
          </div>

          {/* Sync Status */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <RefreshCw className="h-4 w-4" />
              <span className="font-medium">Sync Status</span>
            </div>
            <div className="space-y-1">
              <p className="text-sm">
                {status.syncStatus.syncInProgress ? (
                  <span className="text-yellow-600">Sync in progress...</span>
                ) : (
                  <span className="text-green-600">Idle</span>
                )}
              </p>
              <p className="text-xs text-muted-foreground">
                {status.syncStatus.activeListeners} real-time listeners active
              </p>
              <p className="text-xs text-muted-foreground">
                {status.syncStatus.collections.length} collections synced
              </p>
            </div>
          </div>

          {/* Storage Status */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Shield className="h-4 w-4" />
              <span className="font-medium">Storage</span>
            </div>
            <div className="space-y-1">
              <p className="text-sm">
                {status.storageStatus.available ? (
                  <span className="text-green-600">Available</span>
                ) : (
                  <span className="text-red-600">Unavailable</span>
                )}
              </p>
              <p className="text-xs text-muted-foreground">
                Cloud storage ready for file uploads
              </p>
            </div>
          </div>
        </div>
      </ClayCard>

      {/* Sync Controls */}
      <ClayCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Data Synchronization</h3>
          <ClayButton onClick={syncAllCollections} disabled={status.syncStatus.syncInProgress}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync All Collections
          </ClayButton>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {collections.map((collection) => (
            <div key={collection.name} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span>{collection.icon}</span>
                  <span className="font-medium">{collection.label}</span>
                </div>
                <div className="flex items-center space-x-1">
                  {status.syncStatus.collections.includes(collection.name) ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-yellow-500" />
                  )}
                </div>
              </div>
              
              <div className="flex space-x-2">
                <ClayButton
                  size="sm"
                  onClick={() => syncCollection(collection.name)}
                  disabled={status.syncStatus.syncInProgress}
                >
                  Sync Now
                </ClayButton>
                <ClayButton
                  size="sm"
                  variant="outline"
                  onClick={() => toggleRealtimeSync(collection.name)}
                >
                  {status.syncStatus.collections.includes(collection.name) ? "Stop Real-time" : "Start Real-time"}
                </ClayButton>
              </div>

              {syncResults[collection.name] && (
                <div className={`mt-2 p-2 rounded text-xs ${
                  syncResults[collection.name].success 
                    ? "bg-green-100 text-green-800" 
                    : "bg-red-100 text-red-800"
                }`}>
                  {syncResults[collection.name].message}
                </div>
              )}
            </div>
          ))}
        </div>
      </ClayCard>

      {/* Configuration Instructions */}
      <ClayCard className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Settings className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Firebase Configuration</h3>
        </div>
        
        <div className="space-y-4">
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">Setup Required</h4>
            <p className="text-sm text-yellow-700 mb-3">
              To use Firebase integration, you need to set up a Firebase project and update your environment variables.
            </p>
            <div className="text-xs text-yellow-600 space-y-1">
              <p>1. Create a Firebase project at <a href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer" className="underline">console.firebase.google.com</a></p>
              <p>2. Enable Authentication, Firestore Database, and Cloud Storage</p>
              <p>3. Update the Firebase configuration in your .env file</p>
              <p>4. Configure Firestore security rules and Storage rules</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">Features Available:</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>✅ Real-time data synchronization</li>
                <li>✅ User authentication</li>
                <li>✅ Cloud file storage</li>
                <li>✅ Offline data persistence</li>
                <li>✅ Cross-device synchronization</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Security Features:</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>✅ User authentication and authorization</li>
                <li>✅ Firestore security rules</li>
                <li>✅ Storage security rules</li>
                <li>✅ Data encryption in transit</li>
                <li>✅ Audit logging</li>
              </ul>
            </div>
          </div>
        </div>
      </ClayCard>
    </div>
  )
}