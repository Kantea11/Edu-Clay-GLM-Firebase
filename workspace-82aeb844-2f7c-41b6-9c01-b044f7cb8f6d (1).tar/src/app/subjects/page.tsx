"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  BookOpen, 
  Plus, 
  Search, 
  Filter,
  Edit,
  Trash2,
  Star,
  Book
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"

interface Subject {
  id: string
  subject_name: string
  subject_code: string
  subject_description?: string
  is_core_subject: boolean
  createdAt: string
  updatedAt: string
}

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCoreFilter, setIsCoreFilter] = useState<"all" | "true" | "false">("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    subject_name: "",
    subject_description: "",
    is_core_subject: true,
  })

  useEffect(() => {
    fetchSubjects()
  }, [currentPage, searchTerm, isCoreFilter])

  const fetchSubjects = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "10",
        search: searchTerm,
        isCore: isCoreFilter === "all" ? "" : isCoreFilter
      })
      
      const response = await fetch(`/api/subjects?${params}`)
      const data = await response.json()
      
      if (data.data) {
        setSubjects(data.data)
        setTotalPages(data.pagination.pages)
      }
    } catch (error) {
      console.error("Error fetching subjects:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingSubject ? `/api/subjects/${editingSubject.id}` : "/api/subjects"
      const method = editingSubject ? "PUT" : "POST"
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      })
      
      if (response.ok) {
        await fetchSubjects()
        setIsDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error("Error saving subject:", error)
    }
  }

  const handleEdit = (subject: Subject) => {
    setEditingSubject(subject)
    setFormData({
      subject_name: subject.subject_name,
      subject_description: subject.subject_description || "",
      is_core_subject: subject.is_core_subject,
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this subject?")) return
    
    try {
      const response = await fetch(`/api/subjects/${id}`, {
        method: "DELETE"
      })
      
      if (response.ok) {
        await fetchSubjects()
      }
    } catch (error) {
      console.error("Error deleting subject:", error)
    }
  }

  const resetForm = () => {
    setEditingSubject(null)
    setFormData({
      subject_name: "",
      subject_description: "",
      is_core_subject: true,
    })
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Subjects</h1>
            <p className="text-muted-foreground mt-2">
              Manage academic subjects offered by the school
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <ClayButton onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Subject
              </ClayButton>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editingSubject ? "Edit Subject" : "Add Subject"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="subject_name">Subject Name</Label>
                  <Input
                    id="subject_name"
                    value={formData.subject_name}
                    onChange={(e) => setFormData({ ...formData, subject_name: e.target.value })}
                    placeholder="e.g., Mathematics"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="subject_description">Description (Optional)</Label>
                  <Textarea
                    id="subject_description"
                    value={formData.subject_description}
                    onChange={(e) => setFormData({ ...formData, subject_description: e.target.value })}
                    placeholder="Brief description of the subject..."
                    rows={3}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_core_subject"
                    checked={formData.is_core_subject}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_core_subject: checked })}
                  />
                  <Label htmlFor="is_core_subject">Core Subject</Label>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingSubject ? "Update" : "Create"} Subject
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <ClayCard className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <ClayInput
                  placeholder="Search subjects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={isCoreFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setIsCoreFilter("all")}
              >
                All
              </Button>
              <Button
                variant={isCoreFilter === "true" ? "default" : "outline"}
                size="sm"
                onClick={() => setIsCoreFilter("true")}
              >
                Core
              </Button>
              <Button
                variant={isCoreFilter === "false" ? "default" : "outline"}
                size="sm"
                onClick={() => setIsCoreFilter("false")}
              >
                Elective
              </Button>
            </div>
          </div>
        </ClayCard>

        {/* Subjects List */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Loading subjects...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subjects.map((subject) => (
              <ClayCard key={subject.id} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Book className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{subject.subject_name}</h3>
                      <p className="text-sm text-muted-foreground">{subject.subject_code}</p>
                    </div>
                  </div>
                  {subject.is_core_subject && (
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                  )}
                </div>
                
                {subject.subject_description && (
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {subject.subject_description}
                  </p>
                )}
                
                <div className="flex items-center justify-between">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    subject.is_core_subject 
                      ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" 
                      : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                  }`}>
                    {subject.is_core_subject ? "Core Subject" : "Elective"}
                  </span>
                  
                  <div className="flex items-center space-x-1">
                    <ClayButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(subject)}
                    >
                      <Edit className="h-4 w-4" />
                    </ClayButton>
                    <ClayButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(subject.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </ClayButton>
                  </div>
                </div>
              </ClayCard>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && subjects.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No subjects found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || isCoreFilter !== "all" 
                ? "Try adjusting your filters or search terms." 
                : "Get started by adding your first subject."
              }
            </p>
            {!searchTerm && isCoreFilter === "all" && (
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <ClayButton onClick={resetForm}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Subject
                  </ClayButton>
                </DialogTrigger>
              </Dialog>
            )}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center space-x-2">
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </ClayButton>
            <span className="flex items-center px-4 py-2 text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </ClayButton>
          </div>
        )}
      </div>
    </MainLayout>
  )
}