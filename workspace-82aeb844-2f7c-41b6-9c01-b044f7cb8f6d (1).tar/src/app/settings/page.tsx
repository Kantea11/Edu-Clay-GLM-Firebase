"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  Settings, 
  School, 
  BookOpen, 
  Users, 
  FileText, 
  Database,
  AlertTriangle,
  Save,
  Plus,
  Trash2,
  Edit,
  Wifi
} from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog"
import { FirebaseSettings } from "@/components/firebase-settings"

interface SchoolInfo {
  id: string
  school_name: string
  school_address: string
  school_email?: string
  contact_number_code?: string
  contact_number?: string
  school_motto?: string
  school_logo?: string
  principal_name?: string
  principal_signature?: string
  school_website?: string
  established_year?: number
  show_financials_on_report_card: boolean
  show_arrears_on_report_card: boolean
  class_work_category_weight: number
  exam_category_weight: number
}

interface GradingCriterion {
  id: string
  grade_letter: string
  min_score: number
  max_score: number
  remark?: string
}

interface AssessmentComponent {
  id: string
  component_name: string
  component_category: string
  weight_percentage: number
  max_score: number
  is_active: boolean
  component_order: number
}

interface AutomatedRemark {
  id: string
  remark_type: string
  min_average_score: number
  remark_text: string
}

interface FeeItem {
  id: string
  fee_name: string
  amount: number
  term_id: string
}

interface RequiredItem {
  id: string
  item_name: string
  quantity: number
  details?: string
  term_id: string
}

export default function SettingsPage() {
  const [schoolInfo, setSchoolInfo] = useState<SchoolInfo | null>(null)
  const [gradingCriteria, setGradingCriteria] = useState<GradingCriterion[]>([])
  const [assessmentComponents, setAssessmentComponents] = useState<AssessmentComponent[]>([])
  const [automatedRemarks, setAutomatedRemarks] = useState<AutomatedRemark[]>([])
  const [feeItems, setFeeItems] = useState<FeeItem[]>([])
  const [requiredItems, setRequiredItems] = useState<RequiredItem[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      setLoading(true)
      // Mock data for now - in real app, fetch from API
      setSchoolInfo({
        id: "1",
        school_name: "EduClay International School",
        school_address: "123 Education Street, Learning City",
        school_email: "info@educlay.edu",
        contact_number_code: "+1",
        contact_number: "234-567-8900",
        school_motto: "Excellence in Education",
        principal_name: "Dr. Jane Smith",
        school_website: "https://educlay.edu",
        established_year: 1995,
        show_financials_on_report_card: true,
        show_arrears_on_report_card: true,
        class_work_category_weight: 30,
        exam_category_weight: 70
      })

      setGradingCriteria([
        { id: "1", grade_letter: "A+", min_score: 90, max_score: 100, remark: "Excellent" },
        { id: "2", grade_letter: "A", min_score: 80, max_score: 89, remark: "Very Good" },
        { id: "3", grade_letter: "B+", min_score: 75, max_score: 79, remark: "Good" },
        { id: "4", grade_letter: "B", min_score: 70, max_score: 74, remark: "Satisfactory" },
        { id: "5", grade_letter: "C+", min_score: 65, max_score: 69, remark: "Fair" },
        { id: "6", grade_letter: "C", min_score: 60, max_score: 64, remark: "Pass" },
        { id: "7", grade_letter: "D+", min_score: 55, max_score: 59, remark: "Poor" },
        { id: "8", grade_letter: "D", min_score: 50, max_score: 54, remark: "Very Poor" },
        { id: "9", grade_letter: "F", min_score: 0, max_score: 49, remark: "Fail" }
      ])

      setAssessmentComponents([
        { id: "1", component_name: "Class Tasks", component_category: "Class Work", weight_percentage: 15, max_score: 20, is_active: true, component_order: 1 },
        { id: "2", component_name: "Quizzes", component_category: "Class Work", weight_percentage: 15, max_score: 20, is_active: true, component_order: 2 },
        { id: "3", component_name: "Mid-term Exam", component_category: "Class Work", weight_percentage: 20, max_score: 30, is_active: true, component_order: 3 },
        { id: "4", component_name: "Final Exam", component_category: "End of Term Exam", weight_percentage: 50, max_score: 70, is_active: true, component_order: 4 }
      ])

      setAutomatedRemarks([
        { id: "1", remark_type: "class_teacher", min_average_score: 90, remark_text: "Outstanding performance, shows exceptional potential" },
        { id: "2", remark_type: "class_teacher", min_average_score: 80, remark_text: "Excellent work, maintains high standards" },
        { id: "3", remark_type: "class_teacher", min_average_score: 70, remark_text: "Good progress, continues to improve" },
        { id: "4", remark_type: "class_teacher", min_average_score: 60, remark_text: "Satisfactory performance, needs more effort" },
        { id: "5", remark_type: "principal", min_average_score: 90, remark_text: "Exceptional student, highly recommended" },
        { id: "6", remark_type: "principal", min_average_score: 80, remark_text: "Outstanding achievement, keep it up" }
      ])

      setFeeItems([
        { id: "1", fee_name: "Tuition Fee", amount: 2500, term_id: "term-1" },
        { id: "2", fee_name: "Laboratory Fee", amount: 300, term_id: "term-1" },
        { id: "3", fee_name: "Library Fee", amount: 150, term_id: "term-1" }
      ])

      setRequiredItems([
        { id: "1", item_name: "School Uniform", quantity: 2, details: "Complete set", term_id: "term-1" },
        { id: "2", item_name: "Textbooks", quantity: 1, details: "All subjects", term_id: "term-1" },
        { id: "3", item_name: "Stationery Set", quantity: 1, details: "Pens, pencils, notebooks", term_id: "term-1" }
      ])
    } catch (error) {
      console.error("Error fetching settings:", error)
    } finally {
      setLoading(false)
    }
  }

  const saveSchoolInfo = async () => {
    if (!schoolInfo) return
    
    setSaving(true)
    try {
      // Mock save - in real app, call API
      await new Promise(resolve => setTimeout(resolve, 1000))
      // Show success message
    } catch (error) {
      console.error("Error saving school info:", error)
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading settings...</p>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Settings</h1>
            <p className="text-muted-foreground mt-2">
              Configure school-wide settings, grading criteria, and system preferences
            </p>
          </div>
        </div>

        <Tabs defaultValue="school" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="school">School Info</TabsTrigger>
            <TabsTrigger value="grading">Grading</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
            <TabsTrigger value="remarks">Remarks</TabsTrigger>
            <TabsTrigger value="financials">Financials</TabsTrigger>
            <TabsTrigger value="data">Data</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="firebase">Firebase</TabsTrigger>
          </TabsList>

          <TabsContent value="school" className="space-y-6">
            <ClayCard className="p-6">
              <div className="flex items-center space-x-2 mb-6">
                <School className="h-5 w-5" />
                <h2 className="text-xl font-semibold">School Information</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="school_name">School Name</Label>
                  <Input
                    id="school_name"
                    value={schoolInfo?.school_name || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, school_name: e.target.value } : null)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="school_address">School Address</Label>
                  <Textarea
                    id="school_address"
                    value={schoolInfo?.school_address || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, school_address: e.target.value } : null)}
                    rows={3}
                  />
                </div>
                
                <div>
                  <Label htmlFor="school_email">School Email</Label>
                  <Input
                    id="school_email"
                    type="email"
                    value={schoolInfo?.school_email || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, school_email: e.target.value } : null)}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="contact_number_code">Country Code</Label>
                    <Input
                      id="contact_number_code"
                      value={schoolInfo?.contact_number_code || ""}
                      onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, contact_number_code: e.target.value } : null)}
                      placeholder="+1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact_number">Contact Number</Label>
                    <Input
                      id="contact_number"
                      value={schoolInfo?.contact_number || ""}
                      onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, contact_number: e.target.value } : null)}
                      placeholder="234-567-8900"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="school_motto">School Motto</Label>
                  <Input
                    id="school_motto"
                    value={schoolInfo?.school_motto || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, school_motto: e.target.value } : null)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="principal_name">Principal Name</Label>
                  <Input
                    id="principal_name"
                    value={schoolInfo?.principal_name || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, principal_name: e.target.value } : null)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="school_website">School Website</Label>
                  <Input
                    id="school_website"
                    type="url"
                    value={schoolInfo?.school_website || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, school_website: e.target.value } : null)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="established_year">Established Year</Label>
                  <Input
                    id="established_year"
                    type="number"
                    value={schoolInfo?.established_year || ""}
                    onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, established_year: parseInt(e.target.value) || 0 } : null)}
                  />
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">Report Card Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="show_financials"
                      checked={schoolInfo?.show_financials_on_report_card || false}
                      onCheckedChange={(checked) => setSchoolInfo(prev => prev ? { ...prev, show_financials_on_report_card: checked } : null)}
                    />
                    <Label htmlFor="show_financials">Show financials on report card</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="show_arrears"
                      checked={schoolInfo?.show_arrears_on_report_card || false}
                      onCheckedChange={(checked) => setSchoolInfo(prev => prev ? { ...prev, show_arrears_on_report_card: checked } : null)}
                    />
                    <Label htmlFor="show_arrears">Show arrears on report card</Label>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">Grading Weights</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="class_work_weight">Class Work Category Weight (%)</Label>
                    <Input
                      id="class_work_weight"
                      type="number"
                      min="0"
                      max="100"
                      value={schoolInfo?.class_work_category_weight || 30}
                      onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, class_work_category_weight: parseInt(e.target.value) || 0 } : null)}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="exam_weight">Exam Category Weight (%)</Label>
                    <Input
                      id="exam_weight"
                      type="number"
                      min="0"
                      max="100"
                      value={schoolInfo?.exam_category_weight || 70}
                      onChange={(e) => setSchoolInfo(prev => prev ? { ...prev, exam_category_weight: parseInt(e.target.value) || 0 } : null)}
                    />
                  </div>
                </div>
                
                {schoolInfo && (schoolInfo.class_work_category_weight + schoolInfo.exam_category_weight !== 100) && (
                  <div className="mt-2 text-sm text-red-600">
                    Warning: Class work and exam weights must sum to 100%
                  </div>
                )}
              </div>
              
              <div className="flex justify-end mt-6">
                <ClayButton onClick={saveSchoolInfo} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />
                  {saving ? "Saving..." : "Save Changes"}
                </ClayButton>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="grading">
            <ClayCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5" />
                  <h2 className="text-xl font-semibold">Grading Criteria</h2>
                </div>
                <ClayButton>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Criterion
                </ClayButton>
              </div>
              
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Grade</TableHead>
                      <TableHead>Score Range</TableHead>
                      <TableHead>Remark</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gradingCriteria.map((criterion) => (
                      <TableRow key={criterion.id}>
                        <TableCell>
                          <Badge variant="secondary">{criterion.grade_letter}</Badge>
                        </TableCell>
                        <TableCell>{criterion.min_score} - {criterion.max_score}%</TableCell>
                        <TableCell>{criterion.remark}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-1">
                            <ClayButton variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </ClayButton>
                            <ClayButton variant="ghost" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </ClayButton>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="assessments">
            <ClayCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <h2 className="text-xl font-semibold">Assessment Components</h2>
                </div>
                <ClayButton>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Component
                </ClayButton>
              </div>
              
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Component Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Weight</TableHead>
                      <TableHead>Max Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {assessmentComponents.map((component) => (
                      <TableRow key={component.id}>
                        <TableCell className="font-medium">{component.component_name}</TableCell>
                        <TableCell>
                          <Badge variant={component.component_category === "Class Work" ? "default" : "secondary"}>
                            {component.component_category}
                          </Badge>
                        </TableCell>
                        <TableCell>{component.weight_percentage}%</TableCell>
                        <TableCell>{component.max_score}</TableCell>
                        <TableCell>
                          <Badge variant={component.is_active ? "default" : "outline"}>
                            {component.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-1">
                            <ClayButton variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </ClayButton>
                            <ClayButton variant="ghost" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </ClayButton>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="remarks">
            <ClayCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <h2 className="text-xl font-semibold">Automated Remarks</h2>
                </div>
                <ClayButton>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Remark
                </ClayButton>
              </div>
              
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Min Score</TableHead>
                      <TableHead>Remark Text</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {automatedRemarks.map((remark) => (
                      <TableRow key={remark.id}>
                        <TableCell>
                          <Badge variant="outline">{remark.remark_type}</Badge>
                        </TableCell>
                        <TableCell>{remark.min_average_score}%+</TableCell>
                        <TableCell className="max-w-xs truncate">{remark.remark_text}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-1">
                            <ClayButton variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </ClayButton>
                            <ClayButton variant="ghost" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </ClayButton>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="financials">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ClayCard className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <h2 className="text-xl font-semibold">Fee Items</h2>
                  </div>
                  <ClayButton>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Fee
                  </ClayButton>
                </div>
                
                <div className="space-y-3">
                  {feeItems.map((fee) => (
                    <div key={fee.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium">{fee.fee_name}</div>
                        <div className="text-sm text-muted-foreground">Term: {fee.term_id}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">${fee.amount}</div>
                        <div className="flex space-x-1">
                          <ClayButton variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </ClayButton>
                          <ClayButton variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </ClayButton>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ClayCard>
              
              <ClayCard className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <h2 className="text-xl font-semibold">Required Items</h2>
                  </div>
                  <ClayButton>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </ClayButton>
                </div>
                
                <div className="space-y-3">
                  {requiredItems.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium">{item.item_name}</div>
                        <div className="text-sm text-muted-foreground">
                          Qty: {item.quantity} • {item.details}
                        </div>
                      </div>
                      <div className="flex space-x-1">
                        <ClayButton variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </ClayButton>
                        <ClayButton variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </ClayButton>
                      </div>
                    </div>
                  ))}
                </div>
              </ClayCard>
            </div>
          </TabsContent>

          <TabsContent value="data">
            <ClayCard className="p-6">
              <div className="flex items-center space-x-2 mb-6">
                <Database className="h-5 w-5" />
                <h2 className="text-xl font-semibold">Data Management</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <ClayCard className="p-4 text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Students</h3>
                  <p className="text-sm text-muted-foreground mb-3">Import/Export student data</p>
                  <div className="space-y-2">
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Import
                    </ClayButton>
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Export
                    </ClayButton>
                  </div>
                </ClayCard>
                
                <ClayCard className="p-4 text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Teachers</h3>
                  <p className="text-sm text-muted-foreground mb-3">Import/Export teacher data</p>
                  <div className="space-y-2">
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Import
                    </ClayButton>
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Export
                    </ClayButton>
                  </div>
                </ClayCard>
                
                <ClayCard className="p-4 text-center">
                  <BookOpen className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Subjects</h3>
                  <p className="text-sm text-muted-foreground mb-3">Import/Export subject data</p>
                  <div className="space-y-2">
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Import
                    </ClayButton>
                    <ClayButton variant="outline" size="sm" className="w-full">
                      Export
                    </ClayButton>
                  </div>
                </ClayCard>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">Data Maintenance</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <ClayButton variant="outline" className="w-full">
                    Recalculate Student Counts
                  </ClayButton>
                  <ClayButton variant="outline" className="w-full">
                    Recalculate Grade Positions
                  </ClayButton>
                </div>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="system">
            <ClayCard className="p-6">
              <div className="flex items-center space-x-2 mb-6">
                <Settings className="h-5 w-5" />
                <h2 className="text-xl font-semibold">System Settings</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="language">Language</Label>
                  <Select defaultValue="English">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="French">French</SelectItem>
                      <SelectItem value="Spanish">Spanish</SelectItem>
                      <SelectItem value="German">German</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select defaultValue="USD">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="EUR">EUR (€)</SelectItem>
                      <SelectItem value="GBP">GBP (£)</SelectItem>
                      <SelectItem value="GHS">GHS (₵)</SelectItem>
                      <SelectItem value="NGN">NGN (₦)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="date_format">Date Format</Label>
                  <Select defaultValue="DD/MM/YYYY">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select defaultValue="UTC">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="GMT">GMT</SelectItem>
                      <SelectItem value="EST">EST</SelectItem>
                      <SelectItem value="PST">PST</SelectItem>
                      <SelectItem value="CET">CET</SelectItem>
                      <SelectItem value="WAT">WAT</SelectItem>
                      <SelectItem value="EAT">EAT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <div className="flex items-center space-x-2 mb-4">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  <h3 className="text-lg font-semibold text-red-600">Danger Zone</h3>
                </div>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <ClayButton variant="destructive" className="w-full">
                      Factory Reset
                    </ClayButton>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Factory Reset</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete ALL data from the system including students, teachers, grades, and all settings. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction className="bg-red-600 hover:bg-red-700">
                        Reset System
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </ClayCard>
          </TabsContent>

          <TabsContent value="firebase">
            <FirebaseSettings />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}