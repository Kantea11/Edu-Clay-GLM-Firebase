"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  DoorOpen, 
  Plus, 
  Search, 
  Filter,
  Edit,
  Trash2,
  Users,
  UserCheck,
  BookOpen,
  Calendar,
  MapPin,
  Settings
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

interface Classroom {
  id: string
  class_name: string
  class_code: string
  academic_year: string
  class_teacher_id?: string
  class_status: string
  max_students: number
  classroom_location?: string
  current_student_count: number
  createdAt: string
  updatedAt: string
  class_teacher?: {
    id: string
    full_name: string
    teacher_id: string
  }
  subjects?: Array<{
    id: string
    subject_name: string
    subject_code: string
  }>
  _count?: {
    students: number
  }
}

interface Teacher {
  id: string
  full_name: string
  teacher_id: string
}

interface Subject {
  id: string
  subject_name: string
  subject_code: string
}

export default function ClassroomsPage() {
  const [classrooms, setClassrooms] = useState<Classroom[]>([])
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [academicYearFilter, setAcademicYearFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingClassroom, setEditingClassroom] = useState<Classroom | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    class_name: "",
    academic_year: "",
    class_teacher_id: "",
    class_status: "Active",
    max_students: 30,
    classroom_location: "",
  })

  useEffect(() => {
    fetchClassrooms()
    fetchTeachers()
    fetchSubjects()
  }, [currentPage, searchTerm, statusFilter, academicYearFilter])

  const fetchClassrooms = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "10",
        search: searchTerm,
        status: statusFilter,
        academicYear: academicYearFilter
      })
      
      const response = await fetch(`/api/classrooms?${params}`)
      const data = await response.json()
      
      if (data.data) {
        setClassrooms(data.data)
        setTotalPages(data.pagination.pages)
      }
    } catch (error) {
      console.error("Error fetching classrooms:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchTeachers = async () => {
    try {
      const response = await fetch("/api/teachers?limit=1000")
      const data = await response.json()
      if (data.data) {
        setTeachers(data.data)
      }
    } catch (error) {
      console.error("Error fetching teachers:", error)
    }
  }

  const fetchSubjects = async () => {
    try {
      const response = await fetch("/api/subjects?limit=1000")
      const data = await response.json()
      if (data.data) {
        setSubjects(data.data)
      }
    } catch (error) {
      console.error("Error fetching subjects:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingClassroom ? `/api/classrooms/${editingClassroom.id}` : "/api/classrooms"
      const method = editingClassroom ? "PUT" : "POST"
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      })
      
      if (response.ok) {
        await fetchClassrooms()
        setIsDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error("Error saving classroom:", error)
    }
  }

  const handleEdit = (classroom: Classroom) => {
    setEditingClassroom(classroom)
    setFormData({
      class_name: classroom.class_name,
      academic_year: classroom.academic_year,
      class_teacher_id: classroom.class_teacher_id || "",
      class_status: classroom.class_status,
      max_students: classroom.max_students,
      classroom_location: classroom.classroom_location || "",
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this classroom?")) return
    
    try {
      const response = await fetch(`/api/classrooms/${id}`, {
        method: "DELETE"
      })
      
      if (response.ok) {
        await fetchClassrooms()
      } else {
        const error = await response.json()
        alert(error.error || "Failed to delete classroom")
      }
    } catch (error) {
      console.error("Error deleting classroom:", error)
    }
  }

  const resetForm = () => {
    setEditingClassroom(null)
    setFormData({
      class_name: "",
      academic_year: "",
      class_teacher_id: "",
      class_status: "Active",
      max_students: 30,
      classroom_location: "",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "Inactive":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  const getOccupancyLevel = (current: number, max: number) => {
    const percentage = (current / max) * 100
    if (percentage >= 90) return { color: "text-red-600", level: "High" }
    if (percentage >= 70) return { color: "text-yellow-600", level: "Medium" }
    return { color: "text-green-600", level: "Low" }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Classrooms</h1>
            <p className="text-muted-foreground mt-2">
              Comprehensive management of classrooms, attendance, assignments, and rankings
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <ClayButton onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Classroom
              </ClayButton>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editingClassroom ? "Edit Classroom" : "Add Classroom"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="class_name">Class Name</Label>
                  <Input
                    id="class_name"
                    value={formData.class_name}
                    onChange={(e) => setFormData({ ...formData, class_name: e.target.value })}
                    placeholder="e.g., Grade 5A"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="academic_year">Academic Year</Label>
                  <Input
                    id="academic_year"
                    value={formData.academic_year}
                    onChange={(e) => setFormData({ ...formData, academic_year: e.target.value })}
                    placeholder="2024-2025"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="class_teacher_id">Class Teacher</Label>
                  <Select
                    value={formData.class_teacher_id}
                    onValueChange={(value) => setFormData({ ...formData, class_teacher_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select class teacher" />
                    </SelectTrigger>
                    <SelectContent>
                      {teachers.map((teacher) => (
                        <SelectItem key={teacher.id} value={teacher.id}>
                          {teacher.full_name} ({teacher.teacher_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="max_students">Max Students</Label>
                    <Input
                      id="max_students"
                      type="number"
                      min="1"
                      value={formData.max_students}
                      onChange={(e) => setFormData({ ...formData, max_students: parseInt(e.target.value) || 1 })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="class_status">Status</Label>
                    <Select
                      value={formData.class_status}
                      onValueChange={(value) => setFormData({ ...formData, class_status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="classroom_location">Location (Optional)</Label>
                  <Input
                    id="classroom_location"
                    value={formData.classroom_location}
                    onChange={(e) => setFormData({ ...formData, classroom_location: e.target.value })}
                    placeholder="e.g., Building A, Room 101"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingClassroom ? "Update" : "Create"} Classroom
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="setup" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="setup">Class Setup</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="arrears">Arrears</TabsTrigger>
            <TabsTrigger value="teachers">Teacher Assignment</TabsTrigger>
            <TabsTrigger value="subjects">Subject Assignment</TabsTrigger>
            <TabsTrigger value="rankings">Class Rankings</TabsTrigger>
          </TabsList>

          <TabsContent value="setup" className="space-y-6">
            {/* Filters */}
            <ClayCard className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <ClayInput
                      placeholder="Search classrooms..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={academicYearFilter} onValueChange={setAcademicYearFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Years</SelectItem>
                      <SelectItem value="2024-2025">2024-2025</SelectItem>
                      <SelectItem value="2023-2024">2023-2024</SelectItem>
                      <SelectItem value="2022-2023">2022-2023</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </ClayCard>

            {/* Classrooms List */}
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="mt-2 text-muted-foreground">Loading classrooms...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {classrooms.map((classroom) => {
                  const occupancy = getOccupancyLevel(classroom.current_student_count, classroom.max_students)
                  return (
                    <ClayCard key={classroom.id} className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">
                            {classroom.class_name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {classroom.class_code} • {classroom.academic_year}
                          </p>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(classroom.class_status)}`}>
                          {classroom.class_status}
                        </span>
                      </div>

                      <div className="space-y-3 mb-4">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center text-muted-foreground">
                            <Users className="h-4 w-4 mr-2" />
                            Students
                          </div>
                          <span className="font-medium">
                            {classroom.current_student_count} / {classroom.max_students}
                          </span>
                        </div>
                        
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-300"
                            style={{ 
                              width: `${(classroom.current_student_count / classroom.max_students) * 100}%` 
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between text-xs">
                          <span className={occupancy.color}>
                            Occupancy: {occupancy.level}
                          </span>
                          <span className="text-muted-foreground">
                            {Math.round((classroom.current_student_count / classroom.max_students) * 100)}%
                          </span>
                        </div>

                        {classroom.class_teacher && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <UserCheck className="h-4 w-4 mr-2" />
                            <span>{classroom.class_teacher.full_name}</span>
                          </div>
                        )}

                        {classroom.classroom_location && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4 mr-2" />
                            <span>{classroom.classroom_location}</span>
                          </div>
                        )}

                        {classroom.subjects && classroom.subjects.length > 0 && (
                          <div className="flex items-start text-sm text-muted-foreground">
                            <BookOpen className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                            <div className="flex flex-wrap gap-1">
                              {classroom.subjects.slice(0, 3).map((subject) => (
                                <Badge key={subject.id} variant="secondary" className="text-xs">
                                  {subject.subject_name}
                                </Badge>
                              ))}
                              {classroom.subjects.length > 3 && (
                                <span className="text-xs text-muted-foreground">
                                  +{classroom.subjects.length - 3} more
                                </span>
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-end space-x-2">
                        <ClayButton
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(classroom)}
                        >
                          <Edit className="h-4 w-4" />
                        </ClayButton>
                        <ClayButton
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(classroom.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </ClayButton>
                      </div>
                    </ClayCard>
                  )
                })}
              </div>
            )}

            {/* Empty State */}
            {!loading && classrooms.length === 0 && (
              <div className="text-center py-12">
                <DoorOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No classrooms found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm || statusFilter !== "all" || academicYearFilter !== "all" 
                    ? "Try adjusting your filters or search terms." 
                    : "Get started by adding your first classroom."
                  }
                </p>
                {!searchTerm && statusFilter === "all" && academicYearFilter === "all" && (
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <ClayButton onClick={resetForm}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Classroom
                      </ClayButton>
                    </DialogTrigger>
                  </Dialog>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="attendance">
            <ClayCard className="p-8 text-center">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Attendance Management</h3>
              <p className="text-muted-foreground">
                Record and manage student attendance by class and term. Search students within selected class.
              </p>
            </ClayCard>
          </TabsContent>

          <TabsContent value="arrears">
            <ClayCard className="p-8 text-center">
              <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Arrears Management</h3>
              <p className="text-muted-foreground">
                Track and manage outstanding financial amounts for students per term. Filter by class, search by student.
              </p>
            </ClayCard>
          </TabsContent>

          <TabsContent value="teachers">
            <ClayCard className="p-8 text-center">
              <UserCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Teacher Assignment</h3>
              <p className="text-muted-foreground">
                Assign specific teachers to teach subjects within a class.
              </p>
            </ClayCard>
          </TabsContent>

          <TabsContent value="subjects">
            <ClayCard className="p-8 text-center">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Subject Assignment</h3>
              <p className="text-muted-foreground">
                Assign subjects (core/elective) to specific classes, with enhanced UI for clarity.
              </p>
            </ClayCard>
          </TabsContent>

          <TabsContent value="rankings">
            <ClayCard className="p-8 text-center">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Class Rankings</h3>
              <p className="text-muted-foreground">
                View student rankings based on overall performance within a class, for a selected term.
                Displays dynamic weights for class work and exams from settings.
              </p>
            </ClayCard>
          </TabsContent>
        </Tabs>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center space-x-2">
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </ClayButton>
            <span className="flex items-center px-4 py-2 text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </ClayButton>
          </div>
        )}
      </div>
    </MainLayout>
  )
}