"use client"

import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { 
  Users, 
  UserCheck, 
  DoorOpen, 
  BookOpen, 
  Plus, 
  FileText, 
  Calendar,
  TrendingUp,
  Clock
} from "lucide-react"

export default function Dashboard() {
  // Mock data for dashboard
  const stats = [
    {
      title: "Total Students",
      value: "1,234",
      change: "+12%",
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Total Teachers",
      value: "67",
      change: "+5%",
      icon: UserCheck,
      color: "text-green-600"
    },
    {
      title: "Total Classes",
      value: "24",
      change: "+8%",
      icon: DoorOpen,
      color: "text-purple-600"
    },
    {
      title: "Total Subjects",
      value: "18",
      change: "+2%",
      icon: BookOpen,
      color: "text-orange-600"
    }
  ]

  const quickActions = [
    {
      title: "Add Student",
      description: "Register a new student",
      icon: Plus,
      href: "/students"
    },
    {
      title: "Enter Grades",
      description: "Record student assessments",
      icon: FileText,
      href: "/grades"
    },
    {
      title: "Generate Reports",
      description: "Create report cards",
      icon: FileText,
      href: "/reports"
    },
    {
      title: "Manage Terms",
      description: "Configure academic terms",
      icon: Calendar,
      href: "/academic-terms"
    }
  ]

  const recentActivity = [
    {
      action: "New student enrolled",
      details: "John Doe - Class 5A",
      time: "2 hours ago",
      icon: Users
    },
    {
      action: "Grades updated",
      details: "Mathematics - Class 6B",
      time: "5 hours ago",
      icon: FileText
    },
    {
      action: "New term created",
      details: "2024-2025 - 1st Term",
      time: "1 day ago",
      icon: Calendar
    },
    {
      action: "Teacher assigned",
      details: "Ms. Smith - Class 3A",
      time: "2 days ago",
      icon: UserCheck
    }
  ]

  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Welcome back!</h1>
            <p className="text-muted-foreground mt-2">
              Here's what's happening with your school today.
            </p>
          </div>
          <div className="mt-4 sm:mt-0">
            <ClayCard className="inline-flex items-center space-x-2 px-4 py-2">
              <Calendar className="h-5 w-5 text-primary" />
              <span className="font-medium">Current Term: 2024-2025 - 1st Term</span>
            </ClayCard>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <ClayCard key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500">{stat.change}</span>
                  </div>
                </div>
                <div className={`p-3 rounded-lg bg-muted/50`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </ClayCard>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-xl font-semibold text-foreground mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <ClayCard key={index} className="p-6 text-center hover:shadow-lg cursor-pointer">
                <div className="flex flex-col items-center space-y-3">
                  <div className="p-3 rounded-full bg-primary/10">
                    <action.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{action.title}</h3>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                  <ClayButton size="sm" className="mt-2">
                    Go to {action.title.split(' ')[1]}
                  </ClayButton>
                </div>
              </ClayCard>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-xl font-semibold text-foreground mb-4">Recent Activity</h2>
          <ClayCard className="p-6">
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <div className="p-2 rounded-full bg-muted/50">
                    <activity.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{activity.action}</p>
                    <p className="text-sm text-muted-foreground">{activity.details}</p>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-4 w-4 mr-1" />
                    {activity.time}
                  </div>
                </div>
              ))}
            </div>
          </ClayCard>
        </div>
      </div>
    </MainLayout>
  )
}