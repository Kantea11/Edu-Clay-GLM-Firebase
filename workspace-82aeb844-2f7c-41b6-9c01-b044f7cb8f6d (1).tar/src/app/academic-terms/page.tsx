"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  Calendar, 
  Plus, 
  Search, 
  Filter,
  Edit,
  Trash2,
  CheckCircle,
  Clock,
  XCircle
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface AcademicTerm {
  id: string
  academic_year: string
  term_number: string
  term_start_date: string
  term_end_date: string
  vacation_start_date: string
  school_reopening_date: string
  number_of_holidays: number
  midterm_break_days: number
  total_school_days: number
  is_current_term: boolean
  status: string
  createdAt: string
  updatedAt: string
}

export default function AcademicTermsPage() {
  const [terms, setTerms] = useState<AcademicTerm[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingTerm, setEditingTerm] = useState<AcademicTerm | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    academic_year: "",
    term_number: "1st Term",
    term_start_date: "",
    term_end_date: "",
    vacation_start_date: "",
    school_reopening_date: "",
    number_of_holidays: 0,
    midterm_break_days: 0,
    is_current_term: false,
    status: "Upcoming"
  })

  useEffect(() => {
    fetchTerms()
  }, [currentPage, searchTerm, statusFilter])

  const fetchTerms = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "10",
        search: searchTerm,
        status: statusFilter
      })
      
      const response = await fetch(`/api/academic-terms?${params}`)
      const data = await response.json()
      
      if (data.data) {
        setTerms(data.data)
        setTotalPages(data.pagination.pages)
      }
    } catch (error) {
      console.error("Error fetching terms:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingTerm ? `/api/academic-terms/${editingTerm.id}` : "/api/academic-terms"
      const method = editingTerm ? "PUT" : "POST"
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      })
      
      if (response.ok) {
        await fetchTerms()
        setIsDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error("Error saving term:", error)
    }
  }

  const handleEdit = (term: AcademicTerm) => {
    setEditingTerm(term)
    setFormData({
      academic_year: term.academic_year,
      term_number: term.term_number,
      term_start_date: term.term_start_date.split('T')[0],
      term_end_date: term.term_end_date.split('T')[0],
      vacation_start_date: term.vacation_start_date.split('T')[0],
      school_reopening_date: term.school_reopening_date.split('T')[0],
      number_of_holidays: term.number_of_holidays,
      midterm_break_days: term.midterm_break_days,
      is_current_term: term.is_current_term,
      status: term.status
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this academic term?")) return
    
    try {
      const response = await fetch(`/api/academic-terms/${id}`, {
        method: "DELETE"
      })
      
      if (response.ok) {
        await fetchTerms()
      }
    } catch (error) {
      console.error("Error deleting term:", error)
    }
  }

  const resetForm = () => {
    setEditingTerm(null)
    setFormData({
      academic_year: "",
      term_number: "1st Term",
      term_start_date: "",
      term_end_date: "",
      vacation_start_date: "",
      school_reopening_date: "",
      number_of_holidays: 0,
      midterm_break_days: 0,
      is_current_term: false,
      status: "Upcoming"
    })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Active":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "Upcoming":
        return <Clock className="h-4 w-4 text-blue-500" />
      case "Completed":
        return <XCircle className="h-4 w-4 text-gray-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Academic Terms</h1>
            <p className="text-muted-foreground mt-2">
              Manage academic years and terms for the school calendar
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <ClayButton onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Term
              </ClayButton>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingTerm ? "Edit Academic Term" : "Add Academic Term"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="academic_year">Academic Year</Label>
                    <Input
                      id="academic_year"
                      value={formData.academic_year}
                      onChange={(e) => setFormData({ ...formData, academic_year: e.target.value })}
                      placeholder="2024-2025"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="term_number">Term Number</Label>
                    <Select
                      value={formData.term_number}
                      onValueChange={(value) => setFormData({ ...formData, term_number: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1st Term">1st Term</SelectItem>
                        <SelectItem value="2nd Term">2nd Term</SelectItem>
                        <SelectItem value="3rd Term">3rd Term</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="term_start_date">Term Start Date</Label>
                    <Input
                      id="term_start_date"
                      type="date"
                      value={formData.term_start_date}
                      onChange={(e) => setFormData({ ...formData, term_start_date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="term_end_date">Term End Date</Label>
                    <Input
                      id="term_end_date"
                      type="date"
                      value={formData.term_end_date}
                      onChange={(e) => setFormData({ ...formData, term_end_date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="vacation_start_date">Vacation Start Date</Label>
                    <Input
                      id="vacation_start_date"
                      type="date"
                      value={formData.vacation_start_date}
                      onChange={(e) => setFormData({ ...formData, vacation_start_date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="school_reopening_date">School Reopening Date</Label>
                    <Input
                      id="school_reopening_date"
                      type="date"
                      value={formData.school_reopening_date}
                      onChange={(e) => setFormData({ ...formData, school_reopening_date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="number_of_holidays">Number of Holidays</Label>
                    <Input
                      id="number_of_holidays"
                      type="number"
                      min="0"
                      value={formData.number_of_holidays}
                      onChange={(e) => setFormData({ ...formData, number_of_holidays: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="midterm_break_days">Midterm Break Days</Label>
                    <Input
                      id="midterm_break_days"
                      type="number"
                      min="0"
                      value={formData.midterm_break_days}
                      onChange={(e) => setFormData({ ...formData, midterm_break_days: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Upcoming">Upcoming</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="is_current_term"
                      checked={formData.is_current_term}
                      onChange={(e) => setFormData({ ...formData, is_current_term: e.target.checked })}
                      className="rounded"
                    />
                    <Label htmlFor="is_current_term">Set as Current Term</Label>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingTerm ? "Update" : "Create"} Term
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <ClayCard className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <ClayInput
                  placeholder="Search terms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Upcoming">Upcoming</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </ClayCard>

        {/* Terms List */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Loading terms...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {terms.map((term) => (
              <ClayCard key={term.id} className="p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-foreground">
                        {term.academic_year} - {term.term_number}
                      </h3>
                      {getStatusIcon(term.status)}
                      {term.is_current_term && (
                        <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full">
                          Current
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium">Start:</span> {new Date(term.term_start_date).toLocaleDateString()}
                      </div>
                      <div>
                        <span className="font-medium">End:</span> {new Date(term.term_end_date).toLocaleDateString()}
                      </div>
                      <div>
                        <span className="font-medium">School Days:</span> {term.total_school_days}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-4 sm:mt-0">
                    <ClayButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(term)}
                    >
                      <Edit className="h-4 w-4" />
                    </ClayButton>
                    <ClayButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(term.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </ClayButton>
                  </div>
                </div>
              </ClayCard>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center space-x-2">
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </ClayButton>
            <span className="flex items-center px-4 py-2 text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </ClayButton>
          </div>
        )}
      </div>
    </MainLayout>
  )
}