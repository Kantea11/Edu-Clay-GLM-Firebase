"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  Users, 
  Plus, 
  Search, 
  Filter,
  Edit,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Briefcase,
  UserCheck
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Teacher {
  id: string
  full_name: string
  teacher_id: string
  email: string
  phone?: string
  date_of_employment: string
  employment_status: string
  teacher_photo?: string
  digital_signature?: string
  createdAt: string
  updatedAt: string
  teacherSubjects?: Array<{
    id: string
    subject: {
      id: string
      subject_name: string
      subject_code: string
    }
  }>
}

export default function TeachersPage() {
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    date_of_employment: "",
    employment_status: "Active",
    teacher_photo: "",
    digital_signature: "",
  })

  useEffect(() => {
    fetchTeachers()
  }, [currentPage, searchTerm, statusFilter])

  const fetchTeachers = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "12",
        search: searchTerm,
        status: statusFilter
      })
      
      const response = await fetch(`/api/teachers?${params}`)
      const data = await response.json()
      
      if (data.data) {
        setTeachers(data.data)
        setTotalPages(data.pagination.pages)
      }
    } catch (error) {
      console.error("Error fetching teachers:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingTeacher ? `/api/teachers/${editingTeacher.id}` : "/api/teachers"
      const method = editingTeacher ? "PUT" : "POST"
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      })
      
      if (response.ok) {
        await fetchTeachers()
        setIsDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error("Error saving teacher:", error)
    }
  }

  const handleEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher)
    setFormData({
      full_name: teacher.full_name,
      email: teacher.email,
      phone: teacher.phone || "",
      date_of_employment: teacher.date_of_employment.split('T')[0],
      employment_status: teacher.employment_status,
      teacher_photo: teacher.teacher_photo || "",
      digital_signature: teacher.digital_signature || "",
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this teacher?")) return
    
    try {
      const response = await fetch(`/api/teachers/${id}`, {
        method: "DELETE"
      })
      
      if (response.ok) {
        await fetchTeachers()
      } else {
        const error = await response.json()
        alert(error.error || "Failed to delete teacher")
      }
    } catch (error) {
      console.error("Error deleting teacher:", error)
    }
  }

  const resetForm = () => {
    setEditingTeacher(null)
    setFormData({
      full_name: "",
      email: "",
      phone: "",
      date_of_employment: "",
      employment_status: "Active",
      teacher_photo: "",
      digital_signature: "",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "Inactive":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "On Leave":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Teachers</h1>
            <p className="text-muted-foreground mt-2">
              Manage teacher profiles and their academic specializations
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <ClayButton onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Teacher
              </ClayButton>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingTeacher ? "Edit Teacher" : "Add Teacher"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 234 567 8900"
                    />
                  </div>
                  <div>
                    <Label htmlFor="date_of_employment">Date of Employment</Label>
                    <Input
                      id="date_of_employment"
                      type="date"
                      value={formData.date_of_employment}
                      onChange={(e) => setFormData({ ...formData, date_of_employment: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="employment_status">Employment Status</Label>
                    <Select
                      value={formData.employment_status}
                      onValueChange={(value) => setFormData({ ...formData, employment_status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                        <SelectItem value="On Leave">On Leave</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingTeacher ? "Update" : "Create"} Teacher
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <ClayCard className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <ClayInput
                  placeholder="Search teachers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
                <SelectItem value="On Leave">On Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </ClayCard>

        {/* Teachers Grid */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Loading teachers...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teachers.map((teacher) => (
              <ClayCard key={teacher.id} className="p-6">
                <div className="flex items-start space-x-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={teacher.teacher_photo} alt={teacher.full_name} />
                    <AvatarFallback>
                      {teacher.full_name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground truncate">
                          {teacher.full_name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {teacher.teacher_id}
                        </p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(teacher.employment_status)}`}>
                        {teacher.employment_status}
                      </span>
                    </div>
                    
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Mail className="h-3 w-3 mr-2 flex-shrink-0" />
                        <span className="truncate">{teacher.email}</span>
                      </div>
                      {teacher.phone && (
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Phone className="h-3 w-3 mr-2 flex-shrink-0" />
                          <span>{teacher.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3 mr-2 flex-shrink-0" />
                        <span>Since {new Date(teacher.date_of_employment).toLocaleDateString()}</span>
                      </div>
                    </div>

                    {teacher.teacherSubjects && teacher.teacherSubjects.length > 0 && (
                      <div className="mt-3">
                        <div className="flex items-center text-xs text-muted-foreground mb-1">
                          <Briefcase className="h-3 w-3 mr-1" />
                          Specializations
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {teacher.teacherSubjects.slice(0, 3).map((ts) => (
                            <span
                              key={ts.id}
                              className="text-xs bg-muted px-2 py-1 rounded"
                            >
                              {ts.subject.subject_name}
                            </span>
                          ))}
                          {teacher.teacherSubjects.length > 3 && (
                            <span className="text-xs text-muted-foreground">
                              +{teacher.teacherSubjects.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-end mt-4 space-x-2">
                  <ClayButton
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(teacher)}
                  >
                    <Edit className="h-4 w-4" />
                  </ClayButton>
                  <ClayButton
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(teacher.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </ClayButton>
                </div>
              </ClayCard>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && teachers.length === 0 && (
          <div className="text-center py-12">
            <UserCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No teachers found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || statusFilter !== "all" 
                ? "Try adjusting your filters or search terms." 
                : "Get started by adding your first teacher."
              }
            </p>
            {!searchTerm && statusFilter === "all" && (
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <ClayButton onClick={resetForm}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Teacher
                  </ClayButton>
                </DialogTrigger>
              </Dialog>
            )}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center space-x-2">
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </ClayButton>
            <span className="flex items-center px-4 py-2 text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </ClayButton>
          </div>
        )}
      </div>
    </MainLayout>
  )
}