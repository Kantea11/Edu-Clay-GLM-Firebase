"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  FileText, 
  Download, 
  Search, 
  Filter,
  Users,
  BookOpen,
  Calendar,
  Eye,
  Printer,
  Mail,
  Trophy,
  Award,
  TrendingUp
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

interface ReportCardData {
  student_id: string
  student_name: string
  student_photo?: string
  class_name: string
  term_name: string
  academic_year: string
  overall_percentage: number
  overall_class_position: string
  class_teacher_remark: string
  principal_remark: string
  days_present: number
  total_school_days: number
  attendance_display: string
  subjects: Array<{
    subject_name: string
    class_work_score: number
    end_of_term_exam_score: number
    total_score: number
    percentage: number
    grade_letter: string
    class_position: string
    subject_position: string
  }>
}

interface Classroom {
  id: string
  class_name: string
  class_code: string
  academic_year: string
}

interface AcademicTerm {
  id: string
  academic_year: string
  term_number: string
}

export default function ReportsPage() {
  const [classrooms, setClassrooms] = useState<Classroom[]>([])
  const [terms, setTerms] = useState<AcademicTerm[]>([])
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedTerm, setSelectedTerm] = useState("all")
  const [selectedStudent, setSelectedStudent] = useState("all")
  const [loading, setLoading] = useState(false)
  const [reports, setReports] = useState<ReportCardData[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  useEffect(() => {
    fetchClassrooms()
    fetchTerms()
  }, [])

  const fetchClassrooms = async () => {
    try {
      const response = await fetch("/api/classrooms?limit=1000&status=Active")
      const data = await response.json()
      if (data.data) {
        setClassrooms(data.data)
      }
    } catch (error) {
      console.error("Error fetching classrooms:", error)
    }
  }

  const fetchTerms = async () => {
    try {
      const response = await fetch("/api/academic-terms?limit=1000")
      const data = await response.json()
      if (data.data) {
        setTerms(data.data)
      }
    } catch (error) {
      console.error("Error fetching terms:", error)
    }
  }

  const generateReports = async () => {
    if (selectedTerm === "all") {
      alert("Please select a term to generate reports")
      return
    }

    setIsGenerating(true)
    setLoading(true)

    try {
      // Simulate report generation with mock data
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const mockReports: ReportCardData[] = [
        {
          student_id: "S001",
          student_name: "John Doe",
          class_name: "Grade 5A",
          term_name: "1st Term",
          academic_year: "2024-2025",
          overall_percentage: 87.5,
          overall_class_position: "3rd",
          class_teacher_remark: "Excellent performance, shows great potential",
          principal_remark: "Outstanding student, keep up the good work",
          days_present: 85,
          total_school_days: 90,
          attendance_display: "85 OUT OF 90",
          subjects: [
            {
              subject_name: "Mathematics",
              class_work_score: 88,
              end_of_term_exam_score: 90,
              total_score: 89.4,
              percentage: 89.4,
              grade_letter: "A",
              class_position: "2nd",
              subject_position: "5th"
            },
            {
              subject_name: "English",
              class_work_score: 85,
              end_of_term_exam_score: 87,
              total_score: 86.4,
              percentage: 86.4,
              grade_letter: "A",
              class_position: "4th",
              subject_position: "8th"
            },
            {
              subject_name: "Science",
              class_work_score: 90,
              end_of_term_exam_score: 85,
              total_score: 86.5,
              percentage: 86.5,
              grade_letter: "A",
              class_position: "3rd",
              subject_position: "6th"
            }
          ]
        },
        {
          student_id: "S002",
          student_name: "Jane Smith",
          class_name: "Grade 5A",
          term_name: "1st Term",
          academic_year: "2024-2025",
          overall_percentage: 92.3,
          overall_class_position: "1st",
          class_teacher_remark: "Exceptional work, highly recommended",
          principal_remark: "Top performer, exemplary student",
          days_present: 88,
          total_school_days: 90,
          attendance_display: "88 OUT OF 90",
          subjects: [
            {
              subject_name: "Mathematics",
              class_work_score: 95,
              end_of_term_exam_score: 92,
              total_score: 92.9,
              percentage: 92.9,
              grade_letter: "A+",
              class_position: "1st",
              subject_position: "2nd"
            },
            {
              subject_name: "English",
              class_work_score: 93,
              end_of_term_exam_score: 94,
              total_score: 93.6,
              percentage: 93.6,
              grade_letter: "A+",
              class_position: "1st",
              subject_position: "1st"
            },
            {
              subject_name: "Science",
              class_work_score: 91,
              end_of_term_exam_score: 89,
              total_score: 89.6,
              percentage: 89.6,
              grade_letter: "A",
              class_position: "2nd",
              subject_position: "4th"
            }
          ]
        }
      ]

      setReports(mockReports)
    } catch (error) {
      console.error("Error generating reports:", error)
    } finally {
      setIsGenerating(false)
      setLoading(false)
    }
  }

  const getGradeColor = (grade: string) => {
    switch (grade[0]) {
      case "A":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "B":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "C":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "D":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
      case "F":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  const getPositionColor = (position: string) => {
    const pos = parseInt(position)
    if (pos === 1) return "text-yellow-600"
    if (pos === 2) return "text-gray-400"
    if (pos === 3) return "text-orange-600"
    return "text-muted-foreground"
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Reports</h1>
            <p className="text-muted-foreground mt-2">
              Generate professional report cards for students with comprehensive performance analysis
            </p>
          </div>
        </div>

        {/* Report Generator */}
        <ClayCard className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Report Generator</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Select value={selectedTerm} onValueChange={setSelectedTerm}>
              <SelectTrigger>
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select term" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Select a term</SelectItem>
                {terms.map((term) => (
                  <SelectItem key={term.id} value={term.id}>
                    {term.academic_year} - {term.term_number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger>
                <Users className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="all-students">All Students in System</SelectItem>
                {classrooms.map((classroom) => (
                  <SelectItem key={classroom.id} value={classroom.id}>
                    {classroom.class_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedStudent} onValueChange={setSelectedStudent}>
              <SelectTrigger>
                <BookOpen className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select student" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Students</SelectItem>
                <SelectItem value="individual">Individual Student</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex justify-center">
            <ClayButton 
              onClick={generateReports} 
              disabled={isGenerating || selectedTerm === "all"}
              className="px-8"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Reports
                </>
              )}
            </ClayButton>
          </div>
        </ClayCard>

        {/* Generated Reports */}
        {reports.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-foreground">Generated Report Cards</h2>
              <div className="flex space-x-2">
                <ClayButton variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download All
                </ClayButton>
                <ClayButton variant="outline" size="sm">
                  <Printer className="h-4 w-4 mr-2" />
                  Print All
                </ClayButton>
                <ClayButton variant="outline" size="sm">
                  <Mail className="h-4 w-4 mr-2" />
                  Email All
                </ClayButton>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {reports.map((report, index) => (
                <ClayCard key={index} className="p-6">
                  {/* Report Header */}
                  <div className="border-b pb-4 mb-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={report.student_photo} alt={report.student_name} />
                          <AvatarFallback>
                            {report.student_name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">{report.student_name}</h3>
                          <p className="text-sm text-muted-foreground">{report.student_id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Class Position</div>
                        <div className={`text-2xl font-bold ${getPositionColor(report.overall_class_position)}`}>
                          {report.overall_class_position}
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Class:</span>
                        <span className="ml-2 font-medium">{report.class_name}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Term:</span>
                        <span className="ml-2 font-medium">{report.term_name}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Academic Year:</span>
                        <span className="ml-2 font-medium">{report.academic_year}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Overall Score:</span>
                        <span className="ml-2 font-medium">{report.overall_percentage.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Subjects Performance */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-foreground mb-3">Subject Performance</h4>
                    <div className="space-y-3">
                      {report.subjects.map((subject, subjectIndex) => (
                        <div key={subjectIndex} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div className="flex-1">
                            <div className="font-medium text-foreground">{subject.subject_name}</div>
                            <div className="text-sm text-muted-foreground">
                              CW: {subject.class_work_score} | Exam: {subject.end_of_term_exam_score}
                            </div>
                            <div className="flex items-center space-x-4 mt-1">
                              <span className="text-sm">Total: {subject.total_score.toFixed(1)}</span>
                              <span className="text-sm">{subject.percentage.toFixed(1)}%</span>
                              <Badge className={getGradeColor(subject.grade_letter)}>
                                {subject.grade_letter}
                              </Badge>
                            </div>
                          </div>
                          <div className="text-right text-sm">
                            <div>Class: {subject.class_position}</div>
                            <div>Subject: {subject.subject_position}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Attendance */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-foreground mb-2">Attendance</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{report.attendance_display}</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={(report.days_present / report.total_school_days) * 100} className="w-24" />
                        <span className="text-sm font-medium">
                          {Math.round((report.days_present / report.total_school_days) * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Remarks */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-foreground mb-2">Remarks</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="font-medium text-foreground mb-1">Class Teacher:</div>
                        <div className="text-muted-foreground">{report.class_teacher_remark}</div>
                      </div>
                      <div>
                        <div className="font-medium text-foreground mb-1">Principal:</div>
                        <div className="text-muted-foreground">{report.principal_remark}</div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex justify-end space-x-2 pt-4 border-t">
                    <ClayButton variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </ClayButton>
                    <ClayButton variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </ClayButton>
                    <ClayButton variant="outline" size="sm">
                      <Printer className="h-4 w-4 mr-2" />
                      Print
                    </ClayButton>
                  </div>
                </ClayCard>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {reports.length === 0 && !loading && (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No Reports Generated</h3>
            <p className="text-muted-foreground mb-4">
              Select term, class, and student options, then click "Generate Reports" to create report cards.
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  )
}