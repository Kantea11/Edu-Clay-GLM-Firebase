"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { ClayCard } from "@/components/ui/clay-card"
import { ClayButton } from "@/components/ui/clay-button"
import { ClayInput } from "@/components/ui/clay-input"
import { 
  FileText, 
  Plus, 
  Search, 
  Filter,
  Edit,
  Trash2,
  Download,
  Upload,
  Users,
  BookOpen,
  Calendar,
  Trophy,
  AlertCircle
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog"

interface Grade {
  id: string
  student_id: string
  subject_id: string
  term_id: string
  class_id: string
  class_work_score: number
  end_of_term_exam_score: number
  total_score: number
  percentage: number
  grade_letter: string
  class_position: string
  subject_position: string
  overall_class_position: string
  remarks?: string
  createdAt: string
  updatedAt: string
  student: {
    id: string
    full_name: string
    student_id: string
  }
  subject: {
    id: string
    subject_name: string
    subject_code: string
  }
  term: {
    id: string
    academic_year: string
    term_number: string
  }
  classroom: {
    id: string
    class_name: string
    class_code: string
  }
}

interface Classroom {
  id: string
  class_name: string
  class_code: string
  academic_year: string
}

interface Subject {
  id: string
  subject_name: string
  subject_code: string
}

interface AcademicTerm {
  id: string
  academic_year: string
  term_number: string
}

export default function GradesPage() {
  const [grades, setGrades] = useState<Grade[]>([])
  const [classrooms, setClassrooms] = useState<Classroom[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [terms, setTerms] = useState<AcademicTerm[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedTerm, setSelectedTerm] = useState("all")
  const [selectedSubject, setSelectedSubject] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false)
  const [editingGrade, setEditingGrade] = useState<Grade | null>(null)

  // Form state
  const [formData, setFormData] = useState({
    student_id: "",
    subject_id: "",
    term_id: "",
    class_id: "",
    class_work_score: 0,
    end_of_term_exam_score: 0,
    remarks: "",
  })

  useEffect(() => {
    fetchGrades()
    fetchClassrooms()
    fetchSubjects()
    fetchTerms()
  }, [currentPage, selectedClass, selectedTerm, selectedSubject, searchTerm])

  const fetchGrades = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: "50",
        classId: selectedClass,
        termId: selectedTerm,
        subjectId: selectedSubject,
      })
      
      const response = await fetch(`/api/grades?${params}`)
      const data = await response.json()
      
      if (data.data) {
        setGrades(data.data)
        setTotalPages(data.pagination.pages)
      }
    } catch (error) {
      console.error("Error fetching grades:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchClassrooms = async () => {
    try {
      const response = await fetch("/api/classrooms?limit=1000&status=Active")
      const data = await response.json()
      if (data.data) {
        setClassrooms(data.data)
      }
    } catch (error) {
      console.error("Error fetching classrooms:", error)
    }
  }

  const fetchSubjects = async () => {
    try {
      const response = await fetch("/api/subjects?limit=1000")
      const data = await response.json()
      if (data.data) {
        setSubjects(data.data)
      }
    } catch (error) {
      console.error("Error fetching subjects:", error)
    }
  }

  const fetchTerms = async () => {
    try {
      const response = await fetch("/api/academic-terms?limit=1000")
      const data = await response.json()
      if (data.data) {
        setTerms(data.data)
      }
    } catch (error) {
      console.error("Error fetching terms:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingGrade ? `/api/grades/${editingGrade.id}` : "/api/grades"
      const method = editingGrade ? "PUT" : "POST"
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      })
      
      if (response.ok) {
        await fetchGrades()
        setIsDialogOpen(false)
        resetForm()
      }
    } catch (error) {
      console.error("Error saving grade:", error)
    }
  }

  const handleEdit = (grade: Grade) => {
    setEditingGrade(grade)
    setFormData({
      student_id: grade.student_id,
      subject_id: grade.subject_id,
      term_id: grade.term_id,
      class_id: grade.class_id,
      class_work_score: grade.class_work_score,
      end_of_term_exam_score: grade.end_of_term_exam_score,
      remarks: grade.remarks || "",
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this grade?")) return
    
    try {
      const response = await fetch(`/api/grades/${id}`, {
        method: "DELETE"
      })
      
      if (response.ok) {
        await fetchGrades()
      }
    } catch (error) {
      console.error("Error deleting grade:", error)
    }
  }

  const handleBulkDelete = async () => {
    try {
      const params = new URLSearchParams({
        classId: selectedClass === "all" ? "" : selectedClass,
        subjectId: selectedSubject === "all" ? "" : selectedSubject,
        termId: selectedTerm === "all" ? "" : selectedTerm,
      })
      
      const response = await fetch(`/api/grades?${params}`)
      const data = await response.json()
      
      if (data.data) {
        const deletePromises = data.data.map((grade: Grade) => 
          fetch(`/api/grades/${grade.id}`, { method: "DELETE" })
        )
        
        await Promise.all(deletePromises)
        await fetchGrades()
        setIsBulkDeleteOpen(false)
      }
    } catch (error) {
      console.error("Error bulk deleting grades:", error)
    }
  }

  const handleExport = async () => {
    try {
      const params = new URLSearchParams({
        classId: selectedClass === "all" ? "" : selectedClass,
        subjectId: selectedSubject === "all" ? "" : selectedSubject,
        termId: selectedTerm === "all" ? "" : selectedTerm,
      })
      
      const response = await fetch(`/api/grades?${params}&limit=1000`)
      const data = await response.json()
      
      if (data.data) {
        // Create CSV content
        const headers = ["Student Name", "Student ID", "Subject", "Class", "Term", "Class Work Score", "Exam Score", "Total Score", "Percentage", "Grade", "Class Position", "Subject Position", "Overall Position"]
        const csvContent = [
          headers.join(","),
          ...data.data.map((grade: Grade) => [
            grade.student.full_name,
            grade.student.student_id,
            grade.subject.subject_name,
            grade.classroom.class_name,
            `${grade.term.academic_year} - ${grade.term.term_number}`,
            grade.class_work_score,
            grade.end_of_term_exam_score,
            grade.total_score.toFixed(2),
            grade.percentage.toFixed(2),
            grade.grade_letter,
            grade.class_position,
            grade.subject_position,
            grade.overall_class_position
          ].join(","))
        ].join("\n")
        
        // Download CSV
        const blob = new Blob([csvContent], { type: "text/csv" })
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `grades_${selectedClass}_${selectedSubject}_${selectedTerm}.csv`
        a.click()
        window.URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error("Error exporting grades:", error)
    }
  }

  const resetForm = () => {
    setEditingGrade(null)
    setFormData({
      student_id: "",
      subject_id: "",
      term_id: "",
      class_id: "",
      class_work_score: 0,
      end_of_term_exam_score: 0,
      remarks: "",
    })
  }

  const getGradeColor = (grade: string) => {
    switch (grade[0]) {
      case "A":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "B":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "C":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "D":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
      case "F":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  const filteredGrades = grades.filter(grade =>
    grade.student.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    grade.student.student_id.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Grades</h1>
            <p className="text-muted-foreground mt-2">
              Enter, manage, and import student grades with real-time calculations
            </p>
          </div>
          <div className="flex items-center space-x-2 mt-4 sm:mt-0">
            <AlertDialog open={isBulkDeleteOpen} onOpenChange={setIsBulkDeleteOpen}>
              <AlertDialogTrigger asChild>
                <ClayButton variant="destructive" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Bulk Delete
                </ClayButton>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Bulk Delete Grades</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete all grades for the current filters? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleBulkDelete}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <ClayButton variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </ClayButton>
            <ClayButton variant="outline" size="sm" onClick={() => setIsImportDialogOpen(true)}>
              <Upload className="h-4 w-4 mr-2" />
              Import
            </ClayButton>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <ClayButton onClick={resetForm}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Grade
                </ClayButton>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        {/* Filters */}
        <ClayCard className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger>
                <Users className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classrooms.map((classroom) => (
                  <SelectItem key={classroom.id} value={classroom.id}>
                    {classroom.class_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedTerm} onValueChange={setSelectedTerm}>
              <SelectTrigger>
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select term" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Terms</SelectItem>
                {terms.map((term) => (
                  <SelectItem key={term.id} value={term.id}>
                    {term.academic_year} - {term.term_number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger>
                <BookOpen className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((subject) => (
                  <SelectItem key={subject.id} value={subject.id}>
                    {subject.subject_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <ClayInput
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </ClayCard>

        {/* Grades Table */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Loading grades...</p>
          </div>
        ) : (
          <div className="rounded-lg border overflow-hidden">
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Term</TableHead>
                    <TableHead className="text-center">Class Work</TableHead>
                    <TableHead className="text-center">Exam</TableHead>
                    <TableHead className="text-center">Total</TableHead>
                    <TableHead className="text-center">Grade</TableHead>
                    <TableHead className="text-center">Positions</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredGrades.map((grade) => (
                    <TableRow key={grade.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{grade.student.full_name}</div>
                          <div className="text-sm text-muted-foreground">{grade.student.student_id}</div>
                        </div>
                      </TableCell>
                      <TableCell>{grade.subject.subject_name}</TableCell>
                      <TableCell>{grade.classroom.class_name}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {grade.term.term_number}
                          <div className="text-muted-foreground">{grade.term.academic_year}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="font-medium">{grade.class_work_score}</div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="font-medium">{grade.end_of_term_exam_score}</div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="font-medium">{grade.total_score.toFixed(1)}</div>
                        <div className="text-sm text-muted-foreground">{grade.percentage.toFixed(1)}%</div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={getGradeColor(grade.grade_letter)}>
                          {grade.grade_letter}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="text-xs space-y-1">
                          <div>Class: {grade.class_position}</div>
                          <div>Subject: {grade.subject_position}</div>
                          <div>Overall: {grade.overall_class_position}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-1">
                          <ClayButton
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(grade)}
                          >
                            <Edit className="h-4 w-4" />
                          </ClayButton>
                          <ClayButton
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(grade.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </ClayButton>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredGrades.length === 0 && (
          <div className="text-center py-12">
            <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No grades found</h3>
            <p className="text-muted-foreground mb-4">
              {selectedClass === "all" && selectedTerm === "all" && selectedSubject === "all"
                ? "Select filters and add grades to get started."
                : "Try adjusting your filters or add grades for the selected criteria."
              }
            </p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center space-x-2">
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </ClayButton>
            <span className="flex items-center px-4 py-2 text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <ClayButton
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </ClayButton>
          </div>
        )}

        {/* Add/Edit Grade Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingGrade ? "Edit Grade" : "Add Grade"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="class_id">Class</Label>
                  <Select
                    value={formData.class_id}
                    onValueChange={(value) => setFormData({ ...formData, class_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classrooms.map((classroom) => (
                        <SelectItem key={classroom.id} value={classroom.id}>
                          {classroom.class_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="subject_id">Subject</Label>
                  <Select
                    value={formData.subject_id}
                    onValueChange={(value) => setFormData({ ...formData, subject_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.subject_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="term_id">Term</Label>
                  <Select
                    value={formData.term_id}
                    onValueChange={(value) => setFormData({ ...formData, term_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select term" />
                    </SelectTrigger>
                    <SelectContent>
                      {terms.map((term) => (
                        <SelectItem key={term.id} value={term.id}>
                          {term.academic_year} - {term.term_number}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="student_id">Student</Label>
                  <Select
                    value={formData.student_id}
                    onValueChange={(value) => setFormData({ ...formData, student_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select student" />
                    </SelectTrigger>
                    <SelectContent>
                      {/* This would need to fetch students based on selected class */}
                      <SelectItem value="">Select a class first</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="class_work_score">Class Work Score (0-100)</Label>
                    <Input
                      id="class_work_score"
                      type="number"
                      min="0"
                      max="100"
                      value={formData.class_work_score}
                      onChange={(e) => setFormData({ ...formData, class_work_score: parseFloat(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="end_of_term_exam_score">Exam Score (0-100)</Label>
                    <Input
                      id="end_of_term_exam_score"
                      type="number"
                      min="0"
                      max="100"
                      value={formData.end_of_term_exam_score}
                      onChange={(e) => setFormData({ ...formData, end_of_term_exam_score: parseFloat(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="remarks">Remarks (Optional)</Label>
                  <Input
                    id="remarks"
                    value={formData.remarks}
                    onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    placeholder="Additional comments..."
                  />
                </div>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingGrade ? "Update" : "Create"} Grade
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Import Dialog */}
        <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Import Grades</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Import grades from a CSV file. Download the template first to ensure proper formatting.
              </p>
              <div className="space-y-2">
                <Button variant="outline" className="w-full">
                  <Download className="h-4 w-4 mr-2" />
                  Download Template
                </Button>
                <Button variant="outline" className="w-full">
                  <Upload className="h-4 w-4 mr-2" />
                  Choose CSV File
                </Button>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
                  Cancel
                </Button>
                <Button>Import Grades</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  )
}