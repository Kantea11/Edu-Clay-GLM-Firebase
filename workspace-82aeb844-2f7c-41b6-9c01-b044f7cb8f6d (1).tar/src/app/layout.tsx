import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "EduClay School Management System",
  description: "A comprehensive web application designed for school administration, focusing on student report card generation, academic and financial management, and user-friendly data management.",
  keywords: ["school management", "education", "administration", "report cards", "student management", "teacher management"],
  authors: [{ name: "EduClay Team" }],
  openGraph: {
    title: "EduClay School Management System",
    description: "Comprehensive school administration software with modern UI and powerful features",
    url: "https://educlay.example.com",
    siteName: "EduClay",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "EduClay School Management System",
    description: "Comprehensive school administration software with modern UI and powerful features",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className="font-sans antialiased bg-background text-foreground"
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
