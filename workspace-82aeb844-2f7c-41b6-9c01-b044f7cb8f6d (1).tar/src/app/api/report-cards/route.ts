import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const reportCardSchema = z.object({
  student_id: z.string(),
  term_id: z.string(),
})

// GET /api/report-cards
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const studentId = searchParams.get("studentId")
    const termId = searchParams.get("termId")
    const classId = searchParams.get("classId")

    const where: any = {}
    
    if (studentId && studentId !== "all") where.student_id = studentId
    if (termId && termId !== "all") where.term_id = termId

    let reportCards = await db.reportCard.findMany({
      where,
      include: {
        student: {
          select: {
            id: true,
            full_name: true,
            student_id: true,
            class_id: true,
            gender: true,
            date_of_birth: true,
            date_of_enrollment: true,
            parent_contact: true,
            parent_email: true,
            home_address: true,
            student_photo: true,
            student_status: true,
          }
        },
        term: {
          select: {
            id: true,
            academic_year: true,
            term_number: true,
            term_start_date: true,
            term_end_date: true,
            total_school_days: true,
          }
        }
      },
      orderBy: { generated_date: "desc" }
    })

    // If classId is provided, filter by student's class
    if (classId && classId !== "all") {
      const studentsInClass = await db.student.findMany({
        where: { class_id: classId },
        select: { id: true }
      })
      
      const studentIdsInClass = studentsInClass.map(s => s.id)
      reportCards = reportCards.filter(rc => studentIdsInClass.includes(rc.student_id))
    }

    return NextResponse.json({ data: reportCards })
  } catch (error) {
    console.error("Error fetching report cards:", error)
    return NextResponse.json(
      { error: "Failed to fetch report cards" },
      { status: 500 }
    )
  }
}

// POST /api/report-cards/generate
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { student_id, term_id } = body

    // Check if report card already exists
    const existingReportCard = await db.reportCard.findFirst({
      where: {
        student_id,
        term_id
      }
    })

    if (existingReportCard) {
      return NextResponse.json(
        { error: "Report card already exists for this student and term" },
        { status: 400 }
      )
    }

    // Get student data
    const student = await db.student.findUnique({
      where: { id: student_id },
      include: {
        classroom: {
          select: {
            id: true,
            class_name: true,
            class_code: true,
            class_teacher: {
              select: {
                full_name: true,
                teacher_id: true,
                digital_signature: true
              }
            }
          }
        }
      }
    })

    if (!student) {
      return NextResponse.json(
        { error: "Student not found" },
        { status: 404 }
      )
    }

    // Get term data
    const term = await db.academicTerm.findUnique({
      where: { id: term_id }
    })

    if (!term) {
      return NextResponse.json(
        { error: "Term not found" },
        { status: 404 }
      )
    }

    // Get grades for the student in this term
    const grades = await db.grade.findMany({
      where: {
        student_id,
        term_id
      },
      include: {
        subject: {
          select: {
            subject_name: true,
            subject_code: true
          }
        }
      }
    })

    // Get attendance data
    const attendance = await db.attendance.findFirst({
      where: {
        student_id,
        term_id
      }
    })

    // Get school information
    const schoolInfo = await db.schoolInformation.findFirst()

    // Calculate report card data
    const rawTotalScore = grades.reduce((sum, grade) => sum + grade.total_score, 0)
    const overallPercentage = grades.length > 0 ? rawTotalScore / grades.length : 0
    const daysPresent = attendance?.days_present || 0
    const totalSchoolDays = term.total_school_days
    const attendanceDisplay = `${daysPresent} OUT OF ${totalSchoolDays}`

    // Generate automated remarks
    const classTeacherRemark = generateRemark("class_teacher", overallPercentage)
    const principalRemark = generateRemark("principal", overallPercentage)

    // Create report card
    const reportCard = await db.reportCard.create({
      data: {
        student_id,
        term_id,
        raw_total_score: rawTotalScore,
        overall_percentage: overallPercentage,
        overall_class_position: "",
        class_teacher_remark: classTeacherRemark,
        principal_remark: principalRemark,
        days_present: daysPresent,
        total_school_days: totalSchoolDays,
        attendance_display: attendanceDisplay,
        report_status: "Draft"
      },
      include: {
        student: {
          include: {
            classroom: {
              include: {
                class_teacher: true
              }
            }
          }
        },
        term: true
      }
    })

    return NextResponse.json(reportCard, { status: 201 })
  } catch (error) {
    console.error("Error generating report card:", error)
    return NextResponse.json(
      { error: "Failed to generate report card" },
      { status: 500 }
    )
  }
}

// Helper function to generate automated remarks
function generateRemark(type: string, averageScore: number): string {
  if (averageScore >= 90) {
    return type === "class_teacher" 
      ? "Excellent performance. Keep up the outstanding work!"
      : "Outstanding academic achievement. Congratulations!"
  } else if (averageScore >= 80) {
    return type === "class_teacher"
      ? "Very good performance. Continue to work hard."
      : "Very good academic progress. Keep it up!"
  } else if (averageScore >= 70) {
    return type === "class_teacher"
      ? "Good performance. Room for improvement."
      : "Good academic performance. Strive for excellence."
  } else if (averageScore >= 60) {
    return type === "class_teacher"
      ? "Fair performance. Needs more effort."
      : "Fair performance. Improvement needed."
  } else {
    return type === "class_teacher"
      ? "Poor performance. Requires immediate attention."
      : "Poor performance. Serious improvement needed."
  }
}