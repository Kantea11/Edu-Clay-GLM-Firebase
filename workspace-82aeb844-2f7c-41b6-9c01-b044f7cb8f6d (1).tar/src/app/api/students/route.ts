import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const studentSchema = z.object({
  full_name: z.string().min(1, "Full name is required"),
  class_id: z.string().optional(),
  gender: z.enum(["Male", "Female"]),
  date_of_birth: z.string().min(1, "Date of birth is required"),
  date_of_enrollment: z.string().min(1, "Date of enrollment is required"),
  parent_contact: z.string().optional(),
  parent_email: z.string().email("Valid parent email is required").optional().or(z.literal("")),
  home_address: z.string().optional(),
  student_photo: z.string().optional(),
  student_status: z.enum(["Active", "Inactive", "Transferred"]).default("Active"),
})

// Helper function to generate student ID
function generateStudentId(): string {
  return "S" + Math.floor(Math.random() * 9000 + 1000).toString()
}

// GET /api/students
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const classId = searchParams.get("classId") || ""
    const status = searchParams.get("status") || ""
    const gender = searchParams.get("gender") || ""

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (search) {
      where.OR = [
        { full_name: { contains: search, mode: "insensitive" } },
        { student_id: { contains: search, mode: "insensitive" } },
        { parent_email: { contains: search, mode: "insensitive" } },
      ]
    }
    
    if (classId && classId !== "all") {
      where.class_id = classId
    }
    
    if (status && status !== "all") {
      where.student_status = status
    }
    
    if (gender && gender !== "all") {
      where.gender = gender
    }

    const [students, total] = await Promise.all([
      db.student.findMany({
        where,
        orderBy: { full_name: "asc" },
        skip,
        take: limit,
        include: {
          classroom: {
            select: {
              id: true,
              class_name: true,
              class_code: true,
            }
          }
        }
      }),
      db.student.count({ where }),
    ])

    return NextResponse.json({
      data: students,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching students:", error)
    return NextResponse.json(
      { error: "Failed to fetch students" },
      { status: 500 }
    )
  }
}

// POST /api/students
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = studentSchema.parse(body)

    // Generate student ID
    let studentId = generateStudentId()
    
    // Ensure student ID is unique
    while (await db.student.findUnique({ where: { student_id: studentId } })) {
      studentId = generateStudentId()
    }

    const student = await db.student.create({
      data: {
        ...validatedData,
        student_id: studentId,
        date_of_birth: new Date(validatedData.date_of_birth),
        date_of_enrollment: new Date(validatedData.date_of_enrollment),
        parent_email: validatedData.parent_email || null,
      },
      include: {
        classroom: {
          select: {
            id: true,
            class_name: true,
            class_code: true,
          }
        }
      }
    })

    // Update classroom student count if student is assigned to a class
    if (validatedData.class_id) {
      await db.classroom.update({
        where: { id: validatedData.class_id },
        data: {
          current_student_count: {
            increment: 1
          }
        }
      })
    }

    return NextResponse.json(student, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating student:", error)
    return NextResponse.json(
      { error: "Failed to create student" },
      { status: 500 }
    )
  }
}