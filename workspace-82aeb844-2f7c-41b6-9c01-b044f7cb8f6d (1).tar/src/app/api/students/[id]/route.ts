import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const studentSchema = z.object({
  full_name: z.string().min(1, "Full name is required"),
  class_id: z.string().optional(),
  gender: z.enum(["Male", "Female"]),
  date_of_birth: z.string().min(1, "Date of birth is required"),
  date_of_enrollment: z.string().min(1, "Date of enrollment is required"),
  parent_contact: z.string().optional(),
  parent_email: z.string().email("Valid parent email is required").optional().or(z.literal("")),
  home_address: z.string().optional(),
  student_photo: z.string().optional(),
  student_status: z.enum(["Active", "Inactive", "Transferred"]).default("Active"),
})

// Helper function to generate student ID
function generateStudentId(): string {
  return "S" + Math.floor(Math.random() * 9000 + 1000).toString()
}

// GET /api/students/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const student = await db.student.findUnique({
      where: { id: params.id },
      include: {
        classroom: {
          select: {
            id: true,
            class_name: true,
            class_code: true,
          }
        }
      }
    })

    if (!student) {
      return NextResponse.json(
        { error: "Student not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(student)
  } catch (error) {
    console.error("Error fetching student:", error)
    return NextResponse.json(
      { error: "Failed to fetch student" },
      { status: 500 }
    )
  }
}

// PUT /api/students/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const validatedData = studentSchema.parse(body)

    // Get current student to check class change
    const currentStudent = await db.student.findUnique({
      where: { id: params.id },
      select: { class_id: true }
    })

    const student = await db.student.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        date_of_birth: new Date(validatedData.date_of_birth),
        date_of_enrollment: new Date(validatedData.date_of_enrollment),
        parent_email: validatedData.parent_email || null,
      },
      include: {
        classroom: {
          select: {
            id: true,
            class_name: true,
            class_code: true,
          }
        }
      }
    })

    // Update classroom student counts if class changed
    if (currentStudent && currentStudent.class_id !== validatedData.class_id) {
      // Decrement old class count
      if (currentStudent.class_id) {
        await db.classroom.update({
          where: { id: currentStudent.class_id },
          data: {
            current_student_count: {
              decrement: 1
            }
          }
        })
      }

      // Increment new class count
      if (validatedData.class_id) {
        await db.classroom.update({
          where: { id: validatedData.class_id },
          data: {
            current_student_count: {
              increment: 1
            }
          }
        })
      }
    }

    return NextResponse.json(student)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error updating student:", error)
    return NextResponse.json(
      { error: "Failed to update student" },
      { status: 500 }
    )
  }
}

// DELETE /api/students/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Get student before deletion to update classroom count
    const student = await db.student.findUnique({
      where: { id: params.id },
      select: { class_id: true }
    })

    await db.student.delete({
      where: { id: params.id },
    })

    // Update classroom student count
    if (student && student.class_id) {
      await db.classroom.update({
        where: { id: student.class_id },
        data: {
          current_student_count: {
            decrement: 1
          }
        }
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting student:", error)
    return NextResponse.json(
      { error: "Failed to delete student" },
      { status: 500 }
    )
  }
}