import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const schoolInfoSchema = z.object({
  school_name: z.string().min(1, "School name is required"),
  school_address: z.string().min(1, "School address is required"),
  school_email: z.string().email("Valid school email is required").optional().or(z.literal("")),
  contact_number_code: z.string().optional(),
  contact_number: z.string().optional(),
  school_motto: z.string().optional(),
  school_logo: z.string().optional(),
  principal_name: z.string().optional(),
  principal_signature: z.string().optional(),
  school_website: z.string().optional(),
  established_year: z.number().min(1800).max(new Date().getFullYear()).optional(),
  show_financials_on_report_card: z.boolean().default(true),
  show_arrears_on_report_card: z.boolean().default(true),
  class_work_category_weight: z.number().min(0).max(100).default(30),
  exam_category_weight: z.number().min(0).max(100).default(70),
})

// GET /api/school-information
export async function GET() {
  try {
    let schoolInfo = await db.schoolInformation.findFirst()
    
    // If no school info exists, create default one
    if (!schoolInfo) {
      schoolInfo = await db.schoolInformation.create({
        data: {
          school_name: "My School",
          school_address: "123 School Street, City, Country",
          class_work_category_weight: 30,
          exam_category_weight: 70,
        }
      })
    }

    return NextResponse.json({ data: schoolInfo })
  } catch (error) {
    console.error("Error fetching school information:", error)
    return NextResponse.json(
      { error: "Failed to fetch school information" },
      { status: 500 }
    )
  }
}

// POST /api/school-information
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = schoolInfoSchema.parse(body)

    // Check if weights sum to 100
    if (validatedData.class_work_category_weight + validatedData.exam_category_weight !== 100) {
      return NextResponse.json(
        { error: "Class work and exam category weights must sum to 100%" },
        { status: 400 }
      )
    }

    // Delete existing school info if any
    await db.schoolInformation.deleteMany()

    const schoolInfo = await db.schoolInformation.create({
      data: validatedData
    })

    return NextResponse.json(schoolInfo, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating school information:", error)
    return NextResponse.json(
      { error: "Failed to create school information" },
      { status: 500 }
    )
  }
}