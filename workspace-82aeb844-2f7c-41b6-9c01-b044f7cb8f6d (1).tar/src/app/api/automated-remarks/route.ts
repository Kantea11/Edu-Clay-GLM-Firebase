import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const automatedRemarkSchema = z.object({
  remark_type: z.enum(["class_teacher", "principal", "attitude", "interest"]),
  min_average_score: z.number().min(0).max(100),
  remark_text: z.string().min(1, "Remark text is required"),
})

// GET /api/automated-remarks
export async function GET() {
  try {
    const remarks = await db.automatedRemark.findMany({
      orderBy: [
        { remark_type: "asc" },
        { min_average_score: "desc" }
      ]
    })

    return NextResponse.json({ data: remarks })
  } catch (error) {
    console.error("Error fetching automated remarks:", error)
    return NextResponse.json(
      { error: "Failed to fetch automated remarks" },
      { status: 500 }
    )
  }
}

// POST /api/automated-remarks
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = automatedRemarkSchema.parse(body)

    const remark = await db.automatedRemark.create({
      data: validatedData
    })

    return NextResponse.json(remark, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating automated remark:", error)
    return NextResponse.json(
      { error: "Failed to create automated remark" },
      { status: 500 }
    )
  }
}