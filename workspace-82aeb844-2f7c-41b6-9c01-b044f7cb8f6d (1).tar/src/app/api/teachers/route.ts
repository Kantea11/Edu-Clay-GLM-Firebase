import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const teacherSchema = z.object({
  full_name: z.string().min(1, "Full name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().optional(),
  date_of_employment: z.string().min(1, "Date of employment is required"),
  employment_status: z.enum(["Active", "Inactive", "On Leave"]).default("Active"),
  teacher_photo: z.string().optional(),
  digital_signature: z.string().optional(),
})

// Helper function to generate teacher ID
function generateTeacherId(): string {
  return "T" + Math.floor(Math.random() * 9000 + 1000).toString()
}

// GET /api/teachers
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || ""

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (search) {
      where.OR = [
        { full_name: { contains: search, mode: "insensitive" } },
        { teacher_id: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
      ]
    }
    
    if (status && status !== "all") {
      where.employment_status = status
    }

    const [teachers, total] = await Promise.all([
      db.teacher.findMany({
        where,
        orderBy: { full_name: "asc" },
        skip,
        take: limit,
        include: {
          teacherSubjects: {
            include: {
              subject: true
            }
          }
        }
      }),
      db.teacher.count({ where }),
    ])

    return NextResponse.json({
      data: teachers,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching teachers:", error)
    return NextResponse.json(
      { error: "Failed to fetch teachers" },
      { status: 500 }
    )
  }
}

// POST /api/teachers
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = teacherSchema.parse(body)

    // Check if email already exists
    const existingTeacher = await db.teacher.findUnique({
      where: { email: validatedData.email }
    })

    if (existingTeacher) {
      return NextResponse.json(
        { error: "Teacher with this email already exists" },
        { status: 400 }
      )
    }

    // Generate teacher ID
    let teacherId = generateTeacherId()
    
    // Ensure teacher ID is unique
    while (await db.teacher.findUnique({ where: { teacher_id: teacherId } })) {
      teacherId = generateTeacherId()
    }

    const teacher = await db.teacher.create({
      data: {
        ...validatedData,
        teacher_id: teacherId,
        date_of_employment: new Date(validatedData.date_of_employment),
      },
      include: {
        teacherSubjects: {
          include: {
            subject: true
          }
        }
      }
    })

    return NextResponse.json(teacher, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating teacher:", error)
    return NextResponse.json(
      { error: "Failed to create teacher" },
      { status: 500 }
    )
  }
}