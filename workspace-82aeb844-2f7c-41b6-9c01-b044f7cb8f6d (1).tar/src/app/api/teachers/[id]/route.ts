import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const teacherSchema = z.object({
  full_name: z.string().min(1, "Full name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().optional(),
  date_of_employment: z.string().min(1, "Date of employment is required"),
  employment_status: z.enum(["Active", "Inactive", "On Leave"]).default("Active"),
  teacher_photo: z.string().optional(),
  digital_signature: z.string().optional(),
})

// GET /api/teachers/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const teacher = await db.teacher.findUnique({
      where: { id: params.id },
      include: {
        teacherSubjects: {
          include: {
            subject: true
          }
        }
      }
    })

    if (!teacher) {
      return NextResponse.json(
        { error: "Teacher not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(teacher)
  } catch (error) {
    console.error("Error fetching teacher:", error)
    return NextResponse.json(
      { error: "Failed to fetch teacher" },
      { status: 500 }
    )
  }
}

// PUT /api/teachers/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const validatedData = teacherSchema.parse(body)

    // Check if email already exists excluding current teacher
    const existingTeacher = await db.teacher.findFirst({
      where: {
        email: validatedData.email,
        id: { not: params.id }
      }
    })

    if (existingTeacher) {
      return NextResponse.json(
        { error: "Teacher with this email already exists" },
        { status: 400 }
      )
    }

    const teacher = await db.teacher.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        date_of_employment: new Date(validatedData.date_of_employment),
      },
      include: {
        teacherSubjects: {
          include: {
            subject: true
          }
        }
      }
    })

    return NextResponse.json(teacher)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error updating teacher:", error)
    return NextResponse.json(
      { error: "Failed to update teacher" },
      { status: 500 }
    )
  }
}

// DELETE /api/teachers/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if teacher is assigned as class teacher
    const classroom = await db.classroom.findFirst({
      where: { class_teacher_id: params.id }
    })

    if (classroom) {
      return NextResponse.json(
        { error: "Cannot delete teacher: assigned as class teacher" },
        { status: 400 }
      )
    }

    await db.teacher.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting teacher:", error)
    return NextResponse.json(
      { error: "Failed to delete teacher" },
      { status: 500 }
    )
  }
}