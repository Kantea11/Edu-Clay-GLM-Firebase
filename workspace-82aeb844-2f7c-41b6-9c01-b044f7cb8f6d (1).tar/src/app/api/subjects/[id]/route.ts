import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const subjectSchema = z.object({
  subject_name: z.string().min(1, "Subject name is required"),
  subject_description: z.string().optional(),
  is_core_subject: z.boolean().default(true),
})

// GET /api/subjects/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const subject = await db.subject.findUnique({
      where: { id: params.id },
    })

    if (!subject) {
      return NextResponse.json(
        { error: "Subject not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(subject)
  } catch (error) {
    console.error("Error fetching subject:", error)
    return NextResponse.json(
      { error: "Failed to fetch subject" },
      { status: 500 }
    )
  }
}

// PUT /api/subjects/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const validatedData = subjectSchema.parse(body)

    // Check if subject name already exists (case-insensitive) excluding current subject
    const existingSubject = await db.subject.findFirst({
      where: {
        subject_name: validatedData.subject_name,
        id: { not: params.id }
      }
    })

    if (existingSubject) {
      return NextResponse.json(
        { error: "Subject with this name already exists" },
        { status: 400 }
      )
    }

    const subject = await db.subject.update({
      where: { id: params.id },
      data: validatedData,
    })

    return NextResponse.json(subject)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error updating subject:", error)
    return NextResponse.json(
      { error: "Failed to update subject" },
      { status: 500 }
    )
  }
}

// DELETE /api/subjects/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.subject.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting subject:", error)
    return NextResponse.json(
      { error: "Failed to delete subject" },
      { status: 500 }
    )
  }
}