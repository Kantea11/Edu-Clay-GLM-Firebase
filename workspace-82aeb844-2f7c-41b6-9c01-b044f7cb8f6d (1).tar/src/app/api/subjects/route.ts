import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const subjectSchema = z.object({
  subject_name: z.string().min(1, "Subject name is required"),
  subject_description: z.string().optional(),
  is_core_subject: z.boolean().default(true),
})

// Helper function to generate subject code
function generateSubjectCode(subjectName: string): string {
  const words = subjectName.split(' ')
  if (words.length === 1) {
    return words[0].substring(0, 3).toUpperCase() + '001'
  }
  const code = words.map(word => word.charAt(0).toUpperCase()).join('')
  return code + '001'
}

// GET /api/subjects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const isCore = searchParams.get("isCore")

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (search) {
      where.OR = [
        { subject_name: { contains: search } },
        { subject_code: { contains: search } },
      ]
    }
    
    if (isCore === "true") {
      where.is_core_subject = true
    } else if (isCore === "false") {
      where.is_core_subject = false
    }

    const [subjects, total] = await Promise.all([
      db.subject.findMany({
        where,
        orderBy: { subject_name: "asc" },
        skip,
        take: limit,
      }),
      db.subject.count({ where }),
    ])

    return NextResponse.json({
      data: subjects,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching subjects:", error)
    return NextResponse.json(
      { error: "Failed to fetch subjects" },
      { status: 500 }
    )
  }
}

// POST /api/subjects
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = subjectSchema.parse(body)

    // Check if subject name already exists (case-insensitive)
    const existingSubject = await db.subject.findFirst({
      where: {
        subject_name: validatedData.subject_name
      }
    })

    if (existingSubject) {
      return NextResponse.json(
        { error: "Subject with this name already exists" },
        { status: 400 }
      )
    }

    // Generate subject code
    let subjectCode = generateSubjectCode(validatedData.subject_name)
    
    // Ensure subject code is unique
    let counter = 1
    while (await db.subject.findUnique({ where: { subject_code: subjectCode } })) {
      const baseCode = subjectCode.substring(0, subjectCode.length - 3)
      subjectCode = baseCode + counter.toString().padStart(3, '0')
      counter++
    }

    const subject = await db.subject.create({
      data: {
        ...validatedData,
        subject_code: subjectCode,
      },
    })

    return NextResponse.json(subject, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating subject:", error)
    return NextResponse.json(
      { error: "Failed to create subject" },
      { status: 500 }
    )
  }
}