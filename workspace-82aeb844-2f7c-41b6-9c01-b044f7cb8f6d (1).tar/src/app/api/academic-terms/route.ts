import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const academicTermSchema = z.object({
  academic_year: z.string().min(1, "Academic year is required"),
  term_number: z.enum(["1st Term", "2nd Term", "3rd Term"]),
  term_start_date: z.string().min(1, "Term start date is required"),
  term_end_date: z.string().min(1, "Term end date is required"),
  vacation_start_date: z.string().min(1, "Vacation start date is required"),
  school_reopening_date: z.string().min(1, "School reopening date is required"),
  number_of_holidays: z.number().min(0, "Number of holidays must be non-negative"),
  midterm_break_days: z.number().min(0, "Midterm break days must be non-negative"),
  is_current_term: z.boolean().default(false),
  status: z.enum(["Active", "Upcoming", "Completed"]).default("Upcoming"),
})

// GET /api/academic-terms
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || ""

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (search) {
      where.OR = [
        { academic_year: { contains: search, mode: "insensitive" } },
        { term_number: { contains: search, mode: "insensitive" } },
      ]
    }
    
    if (status && status !== "all") {
      where.status = status
    }

    const [terms, total] = await Promise.all([
      db.academicTerm.findMany({
        where,
        orderBy: { term_start_date: "desc" },
        skip,
        take: limit,
      }),
      db.academicTerm.count({ where }),
    ])

    return NextResponse.json({
      data: terms,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching academic terms:", error)
    return NextResponse.json(
      { error: "Failed to fetch academic terms" },
      { status: 500 }
    )
  }
}

// POST /api/academic-terms
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = academicTermSchema.parse(body)

    // If this is set as current term, unset all other current terms
    if (validatedData.is_current_term) {
      await db.academicTerm.updateMany({
        where: { is_current_term: true },
        data: { is_current_term: false },
      })
    }

    // Calculate total school days
    const startDate = new Date(validatedData.term_start_date)
    const endDate = new Date(validatedData.term_end_date)
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
    const totalSchoolDays = totalDays - validatedData.number_of_holidays - validatedData.midterm_break_days

    const term = await db.academicTerm.create({
      data: {
        ...validatedData,
        total_school_days: Math.max(0, totalSchoolDays),
        term_start_date: new Date(validatedData.term_start_date),
        term_end_date: new Date(validatedData.term_end_date),
        vacation_start_date: new Date(validatedData.vacation_start_date),
        school_reopening_date: new Date(validatedData.school_reopening_date),
      },
    })

    return NextResponse.json(term, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating academic term:", error)
    return NextResponse.json(
      { error: "Failed to create academic term" },
      { status: 500 }
    )
  }
}