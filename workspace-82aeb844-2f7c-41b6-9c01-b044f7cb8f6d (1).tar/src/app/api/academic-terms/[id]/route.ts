import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const academicTermSchema = z.object({
  academic_year: z.string().min(1, "Academic year is required"),
  term_number: z.enum(["1st Term", "2nd Term", "3rd Term"]),
  term_start_date: z.string().min(1, "Term start date is required"),
  term_end_date: z.string().min(1, "Term end date is required"),
  vacation_start_date: z.string().min(1, "Vacation start date is required"),
  school_reopening_date: z.string().min(1, "School reopening date is required"),
  number_of_holidays: z.number().min(0, "Number of holidays must be non-negative"),
  midterm_break_days: z.number().min(0, "Midterm break days must be non-negative"),
  is_current_term: z.boolean().default(false),
  status: z.enum(["Active", "Upcoming", "Completed"]).default("Upcoming"),
})

// GET /api/academic-terms/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const term = await db.academicTerm.findUnique({
      where: { id: params.id },
    })

    if (!term) {
      return NextResponse.json(
        { error: "Academic term not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(term)
  } catch (error) {
    console.error("Error fetching academic term:", error)
    return NextResponse.json(
      { error: "Failed to fetch academic term" },
      { status: 500 }
    )
  }
}

// PUT /api/academic-terms/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const validatedData = academicTermSchema.parse(body)

    // If this is set as current term, unset all other current terms
    if (validatedData.is_current_term) {
      await db.academicTerm.updateMany({
        where: { 
          id: { not: params.id },
          is_current_term: true 
        },
        data: { is_current_term: false },
      })
    }

    // Calculate total school days
    const startDate = new Date(validatedData.term_start_date)
    const endDate = new Date(validatedData.term_end_date)
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
    const totalSchoolDays = totalDays - validatedData.number_of_holidays - validatedData.midterm_break_days

    const term = await db.academicTerm.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        total_school_days: Math.max(0, totalSchoolDays),
        term_start_date: new Date(validatedData.term_start_date),
        term_end_date: new Date(validatedData.term_end_date),
        vacation_start_date: new Date(validatedData.vacation_start_date),
        school_reopening_date: new Date(validatedData.school_reopening_date),
      },
    })

    return NextResponse.json(term)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error updating academic term:", error)
    return NextResponse.json(
      { error: "Failed to update academic term" },
      { status: 500 }
    )
  }
}

// DELETE /api/academic-terms/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.academicTerm.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting academic term:", error)
    return NextResponse.json(
      { error: "Failed to delete academic term" },
      { status: 500 }
    )
  }
}