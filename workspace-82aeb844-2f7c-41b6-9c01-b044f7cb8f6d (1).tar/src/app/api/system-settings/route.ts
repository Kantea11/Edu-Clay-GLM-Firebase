import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const systemSettingsSchema = z.object({
  language: z.enum(["English", "French", "Spanish", "German"]).default("English"),
  currency: z.enum(["USD", "EUR", "GBP", "GHS", "NGN"]).default("USD"),
  date_format: z.enum(["DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD"]).default("DD/MM/YYYY"),
  timezone: z.enum(["UTC", "GMT", "EST", "PST", "CET", "WAT", "EAT"]).default("UTC"),
  academic_year_start_month: z.enum(["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]).default("September"),
  default_term_duration_weeks: z.number().min(1).max(52).default(12),
  report_print_authorization: z.enum(["Admin Only", "Teachers & Admin", "All Users"]).default("Teachers & Admin"),
  default_export_format: z.enum(["PDF", "Excel", "CSV"]).default("PDF"),
})

// GET /api/system-settings
export async function GET() {
  try {
    let settings = await db.systemSettings.findFirst()
    
    // If no settings exist, create default ones
    if (!settings) {
      settings = await db.systemSettings.create({
        data: {
          language: "English",
          currency: "USD",
          date_format: "DD/MM/YYYY",
          timezone: "UTC",
          academic_year_start_month: "September",
          default_term_duration_weeks: 12,
          report_print_authorization: "Teachers & Admin",
          default_export_format: "PDF",
        }
      })
    }

    return NextResponse.json({ data: settings })
  } catch (error) {
    console.error("Error fetching system settings:", error)
    return NextResponse.json(
      { error: "Failed to fetch system settings" },
      { status: 500 }
    )
  }
}

// POST /api/system-settings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = systemSettingsSchema.parse(body)

    // Delete existing settings if any
    await db.systemSettings.deleteMany()

    const settings = await db.systemSettings.create({
      data: validatedData
    })

    return NextResponse.json(settings, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating system settings:", error)
    return NextResponse.json(
      { error: "Failed to create system settings" },
      { status: 500 }
    )
  }
}