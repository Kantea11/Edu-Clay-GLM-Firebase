import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const gradingCriterionSchema = z.object({
  grade_letter: z.string().min(1, "Grade letter is required"),
  min_score: z.number().min(0).max(100),
  max_score: z.number().min(0).max(100),
  remark: z.string().optional(),
})

// GET /api/grading-criteria
export async function GET() {
  try {
    const criteria = await db.gradingCriterion.findMany({
      orderBy: { min_score: "desc" }
    })

    return NextResponse.json({ data: criteria })
  } catch (error) {
    console.error("Error fetching grading criteria:", error)
    return NextResponse.json(
      { error: "Failed to fetch grading criteria" },
      { status: 500 }
    )
  }
}

// POST /api/grading-criteria
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = gradingCriterionSchema.parse(body)

    const criterion = await db.gradingCriterion.create({
      data: validatedData
    })

    return NextResponse.json(criterion, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating grading criterion:", error)
    return NextResponse.json(
      { error: "Failed to create grading criterion" },
      { status: 500 }
    )
  }
}