import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const gradeSchema = z.object({
  student_id: z.string(),
  subject_id: z.string(),
  term_id: z.string(),
  class_id: z.string(),
  class_work_score: z.number().min(0).max(100),
  end_of_term_exam_score: z.number().min(0).max(100),
  remarks: z.string().optional(),
})

// Helper function to calculate grade letter based on percentage
function calculateGradeLetter(percentage: number): string {
  if (percentage >= 90) return "A+"
  if (percentage >= 80) return "A"
  if (percentage >= 75) return "B+"
  if (percentage >= 70) return "B"
  if (percentage >= 65) return "C+"
  if (percentage >= 60) return "C"
  if (percentage >= 55) return "D+"
  if (percentage >= 50) return "D"
  return "F"
}

// Helper function to calculate ordinal position
function getOrdinalPosition(position: number): string {
  const suffixes = ["th", "st", "nd", "rd"]
  const value = position % 100
  return position + (suffixes[(value - 20) % 10] || suffixes[value] || suffixes[0])
}

// GET /api/grades
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId") || ""
    const termId = searchParams.get("termId") || ""
    const subjectId = searchParams.get("subjectId") || ""
    const studentId = searchParams.get("studentId") || ""
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "50")

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (classId && classId !== "all") {
      where.class_id = classId
    }
    
    if (termId && termId !== "all") {
      where.term_id = termId
    }
    
    if (subjectId && subjectId !== "all") {
      where.subject_id = subjectId
    }
    
    if (studentId) {
      where.student_id = studentId
    }

    const [grades, total] = await Promise.all([
      db.grade.findMany({
        where,
        include: {
          student: {
            select: {
              id: true,
              full_name: true,
              student_id: true,
            }
          },
          subject: {
            select: {
              id: true,
              subject_name: true,
              subject_code: true,
            }
          },
          term: {
            select: {
              id: true,
              academic_year: true,
              term_number: true,
            }
          },
          classroom: {
            select: {
              id: true,
              class_name: true,
              class_code: true,
            }
          }
        },
        orderBy: [
          { subject: { subject_name: "asc" } },
          { student: { full_name: "asc" } }
        ],
        skip,
        take: limit,
      }),
      db.grade.count({ where }),
    ])

    return NextResponse.json({
      data: grades,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching grades:", error)
    return NextResponse.json(
      { error: "Failed to fetch grades" },
      { status: 500 }
    )
  }
}

// POST /api/grades
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = gradeSchema.parse(body)

    // Check if grade already exists for this student, subject, and term
    const existingGrade = await db.grade.findFirst({
      where: {
        student_id: validatedData.student_id,
        subject_id: validatedData.subject_id,
        term_id: validatedData.term_id,
      }
    })

    if (existingGrade) {
      return NextResponse.json(
        { error: "Grade already exists for this student, subject, and term" },
        { status: 400 }
      )
    }

    // Get school settings for grade weights
    const schoolSettings = await db.schoolInformation.findFirst()
    const classWorkWeight = schoolSettings?.class_work_category_weight || 30
    const examWeight = schoolSettings?.exam_category_weight || 70

    // Calculate total score and percentage
    const totalScore = (validatedData.class_work_score * classWorkWeight / 100) + 
                      (validatedData.end_of_term_exam_score * examWeight / 100)
    const percentage = totalScore

    // Get all grades for this class, subject, and term to calculate positions
    const classGrades = await db.grade.findMany({
      where: {
        class_id: validatedData.class_id,
        subject_id: validatedData.subject_id,
        term_id: validatedData.term_id,
      },
      orderBy: { percentage: "desc" }
    })

    const subjectGrades = await db.grade.findMany({
      where: {
        subject_id: validatedData.subject_id,
        term_id: validatedData.term_id,
      },
      orderBy: { percentage: "desc" }
    })

    const overallClassGrades = await db.grade.findMany({
      where: {
        class_id: validatedData.class_id,
        term_id: validatedData.term_id,
      },
      orderBy: { percentage: "desc" }
    })

    // Calculate positions
    const classPosition = getOrdinalPosition(classGrades.length + 1)
    const subjectPosition = getOrdinalPosition(subjectGrades.length + 1)
    const overallClassPosition = getOrdinalPosition(overallClassGrades.length + 1)

    const grade = await db.grade.create({
      data: {
        ...validatedData,
        total_score: totalScore,
        percentage,
        grade_letter: calculateGradeLetter(percentage),
        class_position: classPosition,
        subject_position: subjectPosition,
        overall_class_position: overallClassPosition,
      },
      include: {
        student: {
          select: {
            id: true,
            full_name: true,
            student_id: true,
          }
        },
        subject: {
          select: {
            id: true,
            subject_name: true,
            subject_code: true,
          }
        },
        term: {
          select: {
            id: true,
            academic_year: true,
            term_number: true,
          }
        },
        classroom: {
          select: {
            id: true,
            class_name: true,
            class_code: true,
          }
        }
      }
    })

    // Recalculate positions for all affected grades
    await recalculateGradePositions(validatedData.class_id, validatedData.subject_id, validatedData.term_id)

    return NextResponse.json(grade, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating grade:", error)
    return NextResponse.json(
      { error: "Failed to create grade" },
      { status: 500 }
    )
  }
}

// Helper function to recalculate grade positions
async function recalculateGradePositions(classId: string, subjectId: string, termId: string) {
  // Recalculate class positions for subject
  const classSubjectGrades = await db.grade.findMany({
    where: {
      class_id: classId,
      subject_id: subjectId,
      term_id: termId,
    },
    orderBy: { percentage: "desc" }
  })

  for (let i = 0; i < classSubjectGrades.length; i++) {
    await db.grade.update({
      where: { id: classSubjectGrades[i].id },
      data: { class_position: getOrdinalPosition(i + 1) }
    })
  }

  // Recalculate subject positions
  const subjectGrades = await db.grade.findMany({
    where: {
      subject_id: subjectId,
      term_id: termId,
    },
    orderBy: { percentage: "desc" }
  })

  for (let i = 0; i < subjectGrades.length; i++) {
    await db.grade.update({
      where: { id: subjectGrades[i].id },
      data: { subject_position: getOrdinalPosition(i + 1) }
    })
  }

  // Recalculate overall class positions
  const overallClassGrades = await db.grade.findMany({
    where: {
      class_id: classId,
      term_id: termId,
    },
    orderBy: { percentage: "desc" }
  })

  for (let i = 0; i < overallClassGrades.length; i++) {
    await db.grade.update({
      where: { id: overallClassGrades[i].id },
      data: { overall_class_position: getOrdinalPosition(i + 1) }
    })
  }
}