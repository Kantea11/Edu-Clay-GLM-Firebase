import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const classroomSchema = z.object({
  class_name: z.string().min(1, "Class name is required"),
  academic_year: z.string().min(1, "Academic year is required"),
  class_teacher_id: z.string().optional(),
  class_status: z.enum(["Active", "Inactive"]).default("Active"),
  max_students: z.number().min(1, "Max students must be at least 1"),
  classroom_location: z.string().optional(),
})

// Helper function to generate class code
function generateClassCode(className: string, academicYear: string): string {
  const yearShort = academicYear.split('-')[0].substring(2)
  const classShort = className.replace(/\s+/g, '').toUpperCase()
  return `${classShort}-${yearShort}`
}

// GET /api/classrooms
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || ""
    const academicYear = searchParams.get("academicYear") || ""

    const skip = (page - 1) * limit

    const where: any = {}
    
    if (search) {
      where.OR = [
        { class_name: { contains: search, mode: "insensitive" } },
        { class_code: { contains: search, mode: "insensitive" } },
      ]
    }
    
    if (status && status !== "all") {
      where.class_status = status
    }
    
    if (academicYear && academicYear !== "all") {
      where.academic_year = academicYear
    }

    const [classrooms, total] = await Promise.all([
      db.classroom.findMany({
        where,
        orderBy: { class_name: "asc" },
        skip,
        take: limit,
        include: {
          class_teacher: {
            select: {
              id: true,
              full_name: true,
              teacher_id: true,
            }
          },
          subjects: {
            select: {
              id: true,
              subject_name: true,
              subject_code: true,
            }
          },
          _count: {
            select: {
              students: true,
            }
          }
        }
      }),
      db.classroom.count({ where }),
    ])

    return NextResponse.json({
      data: classrooms,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching classrooms:", error)
    return NextResponse.json(
      { error: "Failed to fetch classrooms" },
      { status: 500 }
    )
  }
}

// POST /api/classrooms
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = classroomSchema.parse(body)

    // Check if class name already exists for the academic year
    const existingClassroom = await db.classroom.findFirst({
      where: {
        class_name: validatedData.class_name,
        academic_year: validatedData.academic_year,
      }
    })

    if (existingClassroom) {
      return NextResponse.json(
        { error: "Class with this name already exists for this academic year" },
        { status: 400 }
      )
    }

    // Generate class code
    let classCode = generateClassCode(validatedData.class_name, validatedData.academic_year)
    
    // Ensure class code is unique
    let counter = 1
    while (await db.classroom.findUnique({ where: { class_code: classCode } })) {
      classCode = generateClassCode(validatedData.class_name, validatedData.academic_year) + '-' + counter
      counter++
    }

    const classroom = await db.classroom.create({
      data: {
        ...validatedData,
        class_code: classCode,
        current_student_count: 0,
      },
      include: {
        class_teacher: {
          select: {
            id: true,
            full_name: true,
            teacher_id: true,
          }
        },
        subjects: {
          select: {
            id: true,
            subject_name: true,
            subject_code: true,
          }
        },
        _count: {
          select: {
            students: true,
          }
        }
      }
    })

    return NextResponse.json(classroom, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating classroom:", error)
    return NextResponse.json(
      { error: "Failed to create classroom" },
      { status: 500 }
    )
  }
}