import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const classroomSchema = z.object({
  class_name: z.string().min(1, "Class name is required"),
  academic_year: z.string().min(1, "Academic year is required"),
  class_teacher_id: z.string().optional(),
  class_status: z.enum(["Active", "Inactive"]).default("Active"),
  max_students: z.number().min(1, "Max students must be at least 1"),
  classroom_location: z.string().optional(),
})

// GET /api/classrooms/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const classroom = await db.classroom.findUnique({
      where: { id: params.id },
      include: {
        class_teacher: {
          select: {
            id: true,
            full_name: true,
            teacher_id: true,
          }
        },
        subjects: {
          select: {
            id: true,
            subject_name: true,
            subject_code: true,
          }
        },
        _count: {
          select: {
            students: true,
          }
        }
      }
    })

    if (!classroom) {
      return NextResponse.json(
        { error: "Classroom not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(classroom)
  } catch (error) {
    console.error("Error fetching classroom:", error)
    return NextResponse.json(
      { error: "Failed to fetch classroom" },
      { status: 500 }
    )
  }
}

// PUT /api/classrooms/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const validatedData = classroomSchema.parse(body)

    // Check if class name already exists for the academic year excluding current class
    const existingClassroom = await db.classroom.findFirst({
      where: {
        class_name: validatedData.class_name,
        academic_year: validatedData.academic_year,
        id: { not: params.id }
      }
    })

    if (existingClassroom) {
      return NextResponse.json(
        { error: "Class with this name already exists for this academic year" },
        { status: 400 }
      )
    }

    const classroom = await db.classroom.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        class_teacher: {
          select: {
            id: true,
            full_name: true,
            teacher_id: true,
          }
        },
        subjects: {
          select: {
            id: true,
            subject_name: true,
            subject_code: true,
          }
        },
        _count: {
          select: {
            students: true,
          }
        }
      }
    })

    return NextResponse.json(classroom)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error updating classroom:", error)
    return NextResponse.json(
      { error: "Failed to update classroom" },
      { status: 500 }
    )
  }
}

// DELETE /api/classrooms/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if classroom has students
    const studentCount = await db.student.count({
      where: { class_id: params.id }
    })

    if (studentCount > 0) {
      return NextResponse.json(
        { error: "Cannot delete classroom: has enrolled students" },
        { status: 400 }
      )
    }

    await db.classroom.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting classroom:", error)
    return NextResponse.json(
      { error: "Failed to delete classroom" },
      { status: 500 }
    )
  }
}