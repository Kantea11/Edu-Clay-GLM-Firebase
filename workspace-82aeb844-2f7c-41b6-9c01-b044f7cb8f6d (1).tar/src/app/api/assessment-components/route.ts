import { NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { z } from "zod"

const assessmentComponentSchema = z.object({
  component_name: z.string().min(1, "Component name is required"),
  component_category: z.enum(["Class Work", "End of Term Exam"]),
  weight_percentage: z.number().min(0).max(100),
  max_score: z.number().min(1, "Max score must be at least 1"),
  is_active: z.boolean().default(true),
  component_order: z.number().min(0),
})

// GET /api/assessment-components
export async function GET() {
  try {
    const components = await db.assessmentComponent.findMany({
      orderBy: [
        { component_category: "asc" },
        { component_order: "asc" }
      ]
    })

    return NextResponse.json({ data: components })
  } catch (error) {
    console.error("Error fetching assessment components:", error)
    return NextResponse.json(
      { error: "Failed to fetch assessment components" },
      { status: 500 }
    )
  }
}

// POST /api/assessment-components
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = assessmentComponentSchema.parse(body)

    const component = await db.assessmentComponent.create({
      data: validatedData
    })

    return NextResponse.json(component, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.issues },
        { status: 400 }
      )
    }
    console.error("Error creating assessment component:", error)
    return NextResponse.json(
      { error: "Failed to create assessment component" },
      { status: 500 }
    )
  }
}