import { auth, handleFirebaseError } from "./firebase"
import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  updateEmail,
  updatePassword,
  sendEmailVerification,
  onAuthStateChanged,
  User,
  UserCredential
} from "firebase/auth"
import { firebaseSync } from "./firebase-sync"

interface AuthUser {
  uid: string
  email: string | null
  displayName: string | null
  photoURL: string | null
  emailVerified: boolean
  role: "admin" | "teacher" | "staff"
  lastLogin: Date
  createdAt: Date
}

interface AuthResult {
  success: boolean
  user?: AuthUser
  error?: string
  requiresVerification?: boolean
}

export class FirebaseAuthService {
  private currentUser: AuthUser | null = null
  private authStateListeners: ((user: AuthUser | null) => void)[] = []

  constructor() {
    // Set up auth state listener
    onAuthStateChanged(auth, (user) => {
      if (user) {
        this.currentUser = this.mapFirebaseUser(user)
        this.updateLastLogin(user.uid)
      } else {
        this.currentUser = null
      }
      
      // Notify all listeners
      this.authStateListeners.forEach(listener => listener(this.currentUser))
    })
  }

  /**
   * Register a new user
   */
  async register(
    email: string, 
    password: string, 
    displayName: string,
    role: "admin" | "teacher" | "staff" = "staff"
  ): Promise<AuthResult> {
    try {
      const userCredential: UserCredential = await createUserWithEmailAndPassword(
        auth, 
        email, 
        password
      )

      // Update profile with display name
      await updateProfile(userCredential.user, {
        displayName
      })

      // Send email verification
      await sendEmailVerification(userCredential.user)

      // Create user profile in Firestore
      const userProfile: AuthUser = {
        uid: userCredential.user.uid,
        email: userCredential.user.email,
        displayName: userCredential.user.displayName,
        photoURL: userCredential.user.photoURL,
        emailVerified: userCredential.user.emailVerified,
        role,
        lastLogin: new Date(),
        createdAt: new Date()
      }

      await this.createUserProfile(userProfile)

      return {
        success: true,
        user: userProfile,
        requiresVerification: !userCredential.user.emailVerified
      }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Sign in existing user
   */
  async signIn(email: string, password: string): Promise<AuthResult> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      
      if (!userCredential.user.emailVerified) {
        return {
          success: false,
          error: "Please verify your email before signing in",
          requiresVerification: true
        }
      }

      await this.updateLastLogin(userCredential.user.uid)

      return {
        success: true,
        user: this.mapFirebaseUser(userCredential.user)
      }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Sign out current user
   */
  async signOut(): Promise<void> {
    try {
      await signOut(auth)
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  /**
   * Send password reset email
   */
  async sendPasswordResetEmail(email: string): Promise<{ success: boolean; error?: string }> {
    try {
      await sendPasswordResetEmail(auth, email)
      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Update user profile
   */
  async updateProfile(updates: {
    displayName?: string
    photoURL?: string
  }): Promise<{ success: boolean; error?: string }> {
    try {
      if (!auth.currentUser) {
        return { success: false, error: "No user logged in" }
      }

      await updateProfile(auth.currentUser, updates)
      
      // Update current user object
      if (this.currentUser) {
        this.currentUser = { ...this.currentUser, ...updates }
      }

      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Update user email
   */
  async updateEmail(newEmail: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!auth.currentUser) {
        return { success: false, error: "No user logged in" }
      }

      await updateEmail(auth.currentUser, newEmail)
      
      // Update current user object
      if (this.currentUser) {
        this.currentUser.email = newEmail
      }

      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Update user password
   */
  async updatePassword(newPassword: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!auth.currentUser) {
        return { success: false, error: "No user logged in" }
      }

      await updatePassword(auth.currentUser, newPassword)
      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Resend verification email
   */
  async resendVerificationEmail(): Promise<{ success: boolean; error?: string }> {
    try {
      if (!auth.currentUser) {
        return { success: false, error: "No user logged in" }
      }

      await sendEmailVerification(auth.currentUser)
      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Get current user
   */
  getCurrentUser(): AuthUser | null {
    return this.currentUser
  }

  /**
   * Check if user is authenticated
   */
  isAuthenticated(): boolean {
    return auth.currentUser !== null
  }

  /**
   * Check if user has specific role
   */
  hasRole(role: string): boolean {
    return this.currentUser?.role === role
  }

  /**
   * Check if user is admin
   */
  isAdmin(): boolean {
    return this.hasRole("admin")
  }

  /**
   * Add auth state listener
   */
  onAuthStateChanged(listener: (user: AuthUser | null) => void): () => void {
    this.authStateListeners.push(listener)
    
    // Return unsubscribe function
    return () => {
      const index = this.authStateListeners.indexOf(listener)
      if (index > -1) {
        this.authStateListeners.splice(index, 1)
      }
    }
  }

  /**
   * Map Firebase user to AuthUser
   */
  private mapFirebaseUser(user: User): AuthUser {
    return {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      emailVerified: user.emailVerified,
      role: "staff", // Default role, should be loaded from user profile
      lastLogin: new Date(),
      createdAt: user.metadata.creationTime ? new Date(user.metadata.creationTime) : new Date()
    }
  }

  /**
   * Create user profile in Firestore
   */
  private async createUserProfile(userProfile: AuthUser): Promise<void> {
    try {
      const { db } = await import("./firebase")
      const { doc, setDoc, serverTimestamp } = await import("firebase/firestore")
      
      await setDoc(doc(db, "user_profiles", userProfile.uid), {
        ...userProfile,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      })
    } catch (error) {
      console.error("Error creating user profile:", error)
    }
  }

  /**
   * Update last login timestamp
   */
  private async updateLastLogin(uid: string): Promise<void> {
    try {
      const { db } = await import("./firebase")
      const { doc, updateDoc, serverTimestamp } = await import("firebase/firestore")
      
      await updateDoc(doc(db, "user_profiles", uid), {
        lastLogin: serverTimestamp()
      })
    } catch (error) {
      console.error("Error updating last login:", error)
    }
  }
}

// Export singleton instance
export const firebaseAuth = new FirebaseAuthService()