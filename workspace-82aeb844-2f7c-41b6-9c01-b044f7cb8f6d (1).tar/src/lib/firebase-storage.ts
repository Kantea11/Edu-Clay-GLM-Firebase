import { storage, handleFirebaseError } from "./firebase"
import { 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  deleteObject, 
  listAll,
  getMetadata,
  updateMetadata
} from "firebase/storage"

interface UploadOptions {
  metadata?: {
    contentType?: string
    customMetadata?: Record<string, string>
  }
  onProgress?: (progress: number) => void
}

interface UploadResult {
  success: boolean
  downloadURL?: string
  path?: string
  error?: string
}

interface FileMetadata {
  name: string
  size: number
  contentType: string
  updated: Date
  created: Date
  customMetadata?: Record<string, string>
}

export class FirebaseStorageService {
  private readonly basePath = "school-management"

  /**
   * Upload a file to Firebase Storage
   */
  async uploadFile(
    file: File | Blob,
    path: string,
    options: UploadOptions = {}
  ): Promise<UploadResult> {
    try {
      const fullPath = `${this.basePath}/${path}`
      const storageRef = ref(storage, fullPath)
      
      // Set metadata if provided
      const metadata = options.metadata || {}
      
      await uploadBytes(storageRef, file, metadata)
      
      // Get download URL
      const downloadURL = await getDownloadURL(storageRef)
      
      return {
        success: true,
        downloadURL,
        path: fullPath
      }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Upload student photo
   */
  async uploadStudentPhoto(
    studentId: string,
    file: File | Blob
  ): Promise<UploadResult> {
    const path = `students/${studentId}/photo.${this.getFileExtension(file)}`
    return this.uploadFile(file, path, {
      metadata: {
        contentType: file instanceof File ? file.type : "image/jpeg",
        customMetadata: {
          studentId,
          type: "student-photo"
        }
      }
    })
  }

  /**
   * Upload teacher photo
   */
  async uploadTeacherPhoto(
    teacherId: string,
    file: File | Blob
  ): Promise<UploadResult> {
    const path = `teachers/${teacherId}/photo.${this.getFileExtension(file)}`
    return this.uploadFile(file, path, {
      metadata: {
        contentType: file instanceof File ? file.type : "image/jpeg",
        customMetadata: {
          teacherId,
          type: "teacher-photo"
        }
      }
    })
  }

  /**
   * Upload school logo
   */
  async uploadSchoolLogo(file: File | Blob): Promise<UploadResult> {
    const path = `school/logo.${this.getFileExtension(file)}`
    return this.uploadFile(file, path, {
      metadata: {
        contentType: file instanceof File ? file.type : "image/png",
        customMetadata: {
          type: "school-logo"
        }
      }
    })
  }

  /**
   * Upload principal signature
   */
  async uploadPrincipalSignature(file: File | Blob): Promise<UploadResult> {
    const path = `school/principal-signature.${this.getFileExtension(file)}`
    return this.uploadFile(file, path, {
      metadata: {
        contentType: file instanceof File ? file.type : "image/png",
        customMetadata: {
          type: "principal-signature"
        }
      }
    })
  }

  /**
   * Upload report card (PDF)
   */
  async uploadReportCard(
    studentId: string,
    termId: string,
    file: File | Blob
  ): Promise<UploadResult> {
    const path = `report-cards/${studentId}/${termId}/report-card.pdf`
    return this.uploadFile(file, path, {
      metadata: {
        contentType: "application/pdf",
        customMetadata: {
          studentId,
          termId,
          type: "report-card"
        }
      }
    })
  }

  /**
   * Get download URL for a file
   */
  async getDownloadURL(path: string): Promise<string | null> {
    try {
      const fullPath = `${this.basePath}/${path}`
      const storageRef = ref(storage, fullPath)
      return await getDownloadURL(storageRef)
    } catch (error) {
      console.error("Error getting download URL:", error)
      return null
    }
  }

  /**
   * Delete a file
   */
  async deleteFile(path: string): Promise<{ success: boolean; error?: string }> {
    try {
      const fullPath = `${this.basePath}/${path}`
      const storageRef = ref(storage, fullPath)
      await deleteObject(storageRef)
      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * List files in a directory
   */
  async listFiles(directory: string): Promise<{
    success: boolean
    files?: FileMetadata[]
    error?: string
  }> {
    try {
      const fullPath = `${this.basePath}/${directory}`
      const storageRef = ref(storage, fullPath)
      const result = await listAll(storageRef)
      
      const files: FileMetadata[] = []
      
      for (const itemRef of result.items) {
        try {
          const metadata = await getMetadata(itemRef)
          files.push({
            name: metadata.name,
            size: metadata.size,
            contentType: metadata.contentType || "unknown",
            updated: new Date(metadata.updated),
            created: new Date(metadata.timeCreated),
            customMetadata: metadata.customMetadata
          })
        } catch (error) {
          console.error("Error getting metadata for file:", itemRef.fullPath)
        }
      }
      
      return {
        success: true,
        files
      }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Get file metadata
   */
  async getFileMetadata(path: string): Promise<FileMetadata | null> {
    try {
      const fullPath = `${this.basePath}/${path}`
      const storageRef = ref(storage, fullPath)
      const metadata = await getMetadata(storageRef)
      
      return {
        name: metadata.name,
        size: metadata.size,
        contentType: metadata.contentType || "unknown",
        updated: new Date(metadata.updated),
        created: new Date(metadata.timeCreated),
        customMetadata: metadata.customMetadata
      }
    } catch (error) {
      console.error("Error getting file metadata:", error)
      return null
    }
  }

  /**
   * Update file metadata
   */
  async updateFileMetadata(
    path: string,
    metadata: {
      contentType?: string
      customMetadata?: Record<string, string>
    }
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const fullPath = `${this.basePath}/${path}`
      const storageRef = ref(storage, fullPath)
      await updateMetadata(storageRef, metadata)
      return { success: true }
    } catch (error) {
      const firebaseError = handleFirebaseError(error)
      return {
        success: false,
        error: firebaseError.message
      }
    }
  }

  /**
   * Get file extension from File or Blob
   */
  private getFileExtension(file: File | Blob): string {
    if (file instanceof File && file.name) {
      const lastDot = file.name.lastIndexOf('.')
      return lastDot !== -1 ? file.name.slice(lastDot + 1) : "jpg"
    }
    return "jpg"
  }

  /**
   * Generate a unique filename
   */
  generateUniqueFilename(originalName: string): string {
    const timestamp = Date.now()
    const random = Math.random().toString(36).substring(2, 8)
    const extension = originalName.includes('.') 
      ? originalName.slice(originalName.lastIndexOf('.'))
      : ''
    
    return `${timestamp}_${random}${extension}`
  }

  /**
   * Validate file type
   */
  validateFileType(file: File, allowedTypes: string[]): boolean {
    return allowedTypes.includes(file.type)
  }

  /**
   * Validate file size
   */
  validateFileSize(file: File, maxSizeInBytes: number): boolean {
    return file.size <= maxSizeInBytes
  }
}

// Export singleton instance
export const firebaseStorage = new FirebaseStorageService()