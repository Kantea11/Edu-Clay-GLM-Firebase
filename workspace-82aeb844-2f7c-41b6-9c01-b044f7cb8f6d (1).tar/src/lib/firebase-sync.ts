import { db as prismaDb } from "./db"
import { db as firestoreDb, firebaseCollections, handleFirebaseError } from "./firebase"
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  writeBatch,
  Timestamp
} from "firebase/firestore"
import { auth } from "./firebase"

interface SyncOptions {
  bidirectional?: boolean
  realtime?: boolean
  conflictResolution?: "local-wins" | "remote-wins" | "manual"
}

interface SyncResult {
  success: boolean
  syncedRecords: number
  errors: string[]
  timestamp: Date
}

export class FirebaseSyncService {
  private syncInProgress = false
  private realtimeListeners: Map<string, () => void> = new Map()

  /**
   * Sync a single record from SQLite to Firestore
   */
  async syncRecordToFirebase(
    collectionName: string, 
    localId: string, 
    data: any
  ): Promise<boolean> {
    try {
      const docRef = doc(firestoreDb, collectionName, localId)
      const syncData = {
        ...data,
        _syncedAt: serverTimestamp(),
        _syncVersion: Date.now(),
        _localId: localId
      }
      
      await setDoc(docRef, syncData, { merge: true })
      return true
    } catch (error) {
      console.error(`Error syncing record to Firebase (${collectionName}):`, error)
      return false
    }
  }

  /**
   * Sync a single record from Firestore to SQLite
   */
  async syncRecordFromFirebase(
    collectionName: string, 
    firebaseId: string
  ): Promise<boolean> {
    try {
      const docRef = doc(firestoreDb, collectionName, firebaseId)
      const docSnap = await getDoc(docRef)
      
      if (!docSnap.exists()) {
        return false
      }

      const data = docSnap.data()
      const localId = data._localId || firebaseId
      
      // Remove Firebase-specific fields
      const { _syncedAt, _syncVersion, _localId, ...cleanData } = data
      
      // Convert Timestamps to Dates
      const processedData = this.processTimestamps(cleanData)
      
      // Update local database
      await this.updateLocalRecord(collectionName, localId, processedData)
      return true
    } catch (error) {
      console.error(`Error syncing record from Firebase (${collectionName}):`, error)
      return false
    }
  }

  /**
   * Sync entire collection from SQLite to Firestore
   */
  async syncCollectionToFirebase(
    collectionName: string, 
    options: SyncOptions = {}
  ): Promise<SyncResult> {
    const result: SyncResult = {
      success: false,
      syncedRecords: 0,
      errors: [],
      timestamp: new Date()
    }

    try {
      this.syncInProgress = true
      
      // Get all records from local database
      const localRecords = await this.getLocalRecords(collectionName)
      
      // Sync each record to Firebase
      for (const record of localRecords) {
        const success = await this.syncRecordToFirebase(collectionName, record.id, record)
        if (success) {
          result.syncedRecords++
        } else {
          result.errors.push(`Failed to sync record ${record.id}`)
        }
      }
      
      result.success = result.errors.length === 0
    } catch (error) {
      result.errors.push(handleFirebaseError(error).message)
    } finally {
      this.syncInProgress = false
    }

    return result
  }

  /**
   * Set up real-time synchronization for a collection
   */
  setupRealtimeSync(collectionName: string, callback?: (data: any) => void): () => void {
    const collectionRef = collection(firestoreDb, collectionName)
    
    const unsubscribe = onSnapshot(collectionRef, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        const data = change.doc.data()
        
        switch (change.type) {
          case "added":
          case "modified":
            this.syncRecordFromFirebase(collectionName, change.doc.id)
            break
          case "removed":
            this.deleteLocalRecord(collectionName, change.doc.id)
            break
        }
        
        if (callback) {
          callback({
            type: change.type,
            id: change.doc.id,
            data: data
          })
        }
      })
    })

    this.realtimeListeners.set(collectionName, unsubscribe)
    return unsubscribe
  }

  /**
   * Stop real-time synchronization for a collection
   */
  stopRealtimeSync(collectionName: string): void {
    const unsubscribe = this.realtimeListeners.get(collectionName)
    if (unsubscribe) {
      unsubscribe()
      this.realtimeListeners.delete(collectionName)
    }
  }

  /**
   * Stop all real-time synchronization
   */
  stopAllRealtimeSync(): void {
    this.realtimeListeners.forEach((unsubscribe) => unsubscribe())
    this.realtimeListeners.clear()
  }

  /**
   * Get local records from SQLite database
   */
  private async getLocalRecords(collectionName: string): Promise<any[]> {
    try {
      // Map collection names to Prisma models
      const modelMap: { [key: string]: any } = {
        [firebaseCollections.ACADEMIC_TERMS]: prismaDb.academicTerm,
        [firebaseCollections.SUBJECTS]: prismaDb.subject,
        [firebaseCollections.TEACHERS]: prismaDb.teacher,
        [firebaseCollections.CLASSROOMS]: prismaDb.classroom,
        [firebaseCollections.STUDENTS]: prismaDb.student,
        [firebaseCollections.GRADES]: prismaDb.grade,
        [firebaseCollections.SCHOOL_INFORMATION]: prismaDb.schoolInformation,
        [firebaseCollections.ATTENDANCE]: prismaDb.attendance,
        [firebaseCollections.GRADING_CRITERIA]: prismaDb.gradingCriterion,
        [firebaseCollections.AUTOMATED_REMARKS]: prismaDb.automatedRemark,
        [firebaseCollections.ASSESSMENT_COMPONENTS]: prismaDb.assessmentComponent,
        [firebaseCollections.FEE_ITEMS]: prismaDb.feeItem,
        [firebaseCollections.REQUIRED_ITEMS]: prismaDb.requiredItem,
        [firebaseCollections.STUDENT_ASSESSMENT_SCORES]: prismaDb.studentAssessmentScore,
        [firebaseCollections.REPORT_CARDS]: prismaDb.reportCard,
        [firebaseCollections.ARREARS]: prismaDb.arrears,
        [firebaseCollections.SYSTEM_SETTINGS]: prismaDb.systemSettings,
        [firebaseCollections.TEACHER_SUBJECTS]: prismaDb.teacherSubject
      }

      const model = modelMap[collectionName]
      if (!model) {
        throw new Error(`Unknown collection: ${collectionName}`)
      }

      return await model.findMany()
    } catch (error) {
      console.error(`Error getting local records for ${collectionName}:`, error)
      return []
    }
  }

  /**
   * Update local record in SQLite database
   */
  private async updateLocalRecord(collectionName: string, id: string, data: any): Promise<void> {
    try {
      const modelMap: { [key: string]: any } = {
        [firebaseCollections.ACADEMIC_TERMS]: prismaDb.academicTerm,
        [firebaseCollections.SUBJECTS]: prismaDb.subject,
        [firebaseCollections.TEACHERS]: prismaDb.teacher,
        [firebaseCollections.CLASSROOMS]: prismaDb.classroom,
        [firebaseCollections.STUDENTS]: prismaDb.student,
        [firebaseCollections.GRADES]: prismaDb.grade,
        [firebaseCollections.SCHOOL_INFORMATION]: prismaDb.schoolInformation,
        [firebaseCollections.ATTENDANCE]: prismaDb.attendance,
        [firebaseCollections.GRADING_CRITERIA]: prismaDb.gradingCriterion,
        [firebaseCollections.AUTOMATED_REMARKS]: prismaDb.automatedRemark,
        [firebaseCollections.ASSESSMENT_COMPONENTS]: prismaDb.assessmentComponent,
        [firebaseCollections.FEE_ITEMS]: prismaDb.feeItem,
        [firebaseCollections.REQUIRED_ITEMS]: prismaDb.requiredItem,
        [firebaseCollections.STUDENT_ASSESSMENT_SCORES]: prismaDb.studentAssessmentScore,
        [firebaseCollections.REPORT_CARDS]: prismaDb.reportCard,
        [firebaseCollections.ARREARS]: prismaDb.arrears,
        [firebaseCollections.SYSTEM_SETTINGS]: prismaDb.systemSettings,
        [firebaseCollections.TEACHER_SUBJECTS]: prismaDb.teacherSubject
      }

      const model = modelMap[collectionName]
      if (!model) {
        throw new Error(`Unknown collection: ${collectionName}`)
      }

      await model.update({
        where: { id },
        data
      })
    } catch (error) {
      console.error(`Error updating local record (${collectionName}):`, error)
    }
  }

  /**
   * Delete local record from SQLite database
   */
  private async deleteLocalRecord(collectionName: string, id: string): Promise<void> {
    try {
      const modelMap: { [key: string]: any } = {
        [firebaseCollections.ACADEMIC_TERMS]: prismaDb.academicTerm,
        [firebaseCollections.SUBJECTS]: prismaDb.subject,
        [firebaseCollections.TEACHERS]: prismaDb.teacher,
        [firebaseCollections.CLASSROOMS]: prismaDb.classroom,
        [firebaseCollections.STUDENTS]: prismaDb.student,
        [firebaseCollections.GRADES]: prismaDb.grade,
        [firebaseCollections.SCHOOL_INFORMATION]: prismaDb.schoolInformation,
        [firebaseCollections.ATTENDANCE]: prismaDb.attendance,
        [firebaseCollections.GRADING_CRITERIA]: prismaDb.gradingCriterion,
        [firebaseCollections.AUTOMATED_REMARKS]: prismaDb.automatedRemark,
        [firebaseCollections.ASSESSMENT_COMPONENTS]: prismaDb.assessmentComponent,
        [firebaseCollections.FEE_ITEMS]: prismaDb.feeItem,
        [firebaseCollections.REQUIRED_ITEMS]: prismaDb.requiredItem,
        [firebaseCollections.STUDENT_ASSESSMENT_SCORES]: prismaDb.studentAssessmentScore,
        [firebaseCollections.REPORT_CARDS]: prismaDb.reportCard,
        [firebaseCollections.ARREARS]: prismaDb.arrears,
        [firebaseCollections.SYSTEM_SETTINGS]: prismaDb.systemSettings,
        [firebaseCollections.TEACHER_SUBJECTS]: prismaDb.teacherSubject
      }

      const model = modelMap[collectionName]
      if (!model) {
        throw new Error(`Unknown collection: ${collectionName}`)
      }

      await model.delete({
        where: { id }
      })
    } catch (error) {
      console.error(`Error deleting local record (${collectionName}):`, error)
    }
  }

  /**
   * Process Firebase Timestamps to JavaScript Dates
   */
  private processTimestamps(data: any): any {
    const processed: any = {}
    
    for (const [key, value] of Object.entries(data)) {
      if (value instanceof Timestamp) {
        processed[key] = value.toDate()
      } else if (typeof value === 'object' && value !== null) {
        processed[key] = this.processTimestamps(value)
      } else {
        processed[key] = value
      }
    }
    
    return processed
  }

  /**
   * Get sync status
   */
  getSyncStatus(): {
    syncInProgress: boolean
    activeListeners: number
    collections: string[]
  } {
    return {
      syncInProgress: this.syncInProgress,
      activeListeners: this.realtimeListeners.size,
      collections: Array.from(this.realtimeListeners.keys())
    }
  }
}

// Export singleton instance
export const firebaseSync = new FirebaseSyncService()