import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"

// Firebase configuration - replace with your actual Firebase project config
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "demo-api-key",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "demo-project.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "demo-project",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "demo-project.appspot.com",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:123456789:web:abcdef123456"
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase services
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)

// Export the app instance
export default app

// Helper functions for Firebase operations
export const firebaseCollections = {
  // Main entities
  ACADEMIC_TERMS: "academic_terms",
  SUBJECTS: "subjects",
  TEACHERS: "teachers",
  CLASSROOMS: "classrooms",
  STUDENTS: "students",
  GRADES: "grades",
  SCHOOL_INFORMATION: "school_information",
  ATTENDANCE: "attendance",
  GRADING_CRITERIA: "grading_criteria",
  AUTOMATED_REMARKS: "automated_remarks",
  ASSESSMENT_COMPONENTS: "assessment_components",
  FEE_ITEMS: "fee_items",
  REQUIRED_ITEMS: "required_items",
  STUDENT_ASSESSMENT_SCORES: "student_assessment_scores",
  REPORT_CARDS: "report_cards",
  ARREARS: "arrears",
  SYSTEM_SETTINGS: "system_settings",
  TEACHER_SUBJECTS: "teacher_subjects"
}

// Firebase error handling
export class FirebaseError extends Error {
  constructor(
    message: string,
    public code: string,
    public originalError?: any
  ) {
    super(message)
    this.name = "FirebaseError"
  }
}

// Utility function to handle Firebase errors
export const handleFirebaseError = (error: any): FirebaseError => {
  console.error("Firebase Error:", error)
  
  let message = "An unexpected error occurred"
  let code = "unknown"

  switch (error.code) {
    case "auth/user-not-found":
      message = "User not found"
      code = "USER_NOT_FOUND"
      break
    case "auth/wrong-password":
      message = "Invalid password"
      code = "INVALID_PASSWORD"
      break
    case "auth/email-already-in-use":
      message = "Email already in use"
      code = "EMAIL_ALREADY_IN_USE"
      break
    case "firestore/permission-denied":
      message = "Permission denied"
      code = "PERMISSION_DENIED"
      break
    case "firestore/unavailable":
      message = "Firestore service unavailable"
      code = "SERVICE_UNAVAILABLE"
      break
    case "storage/unauthorized":
      message = "Unauthorized access to storage"
      code = "STORAGE_UNAUTHORIZED"
      break
    default:
      message = error.message || "An unexpected error occurred"
      code = error.code || "UNKNOWN"
  }

  return new FirebaseError(message, code, error)
}